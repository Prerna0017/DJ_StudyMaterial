class w1
{
	public static void main(String args[])
	{	
		String str1 = "45";
		Integer i1 = Integer.valueOf(str1);
		System.out.println("Converting String Into Integer: ");
		System.out.println("Integer Value: "+i1);

		System.out.println("Converting Integer into Primitive data types: ");
		Integer i2 = new Integer (67);
		System.out.println("Byte Value: "+i2.byteValue());
		System.out.println("Double Value: "+i2.doubleValue());
		System.out.println("Float Value: "+i2.floatValue());
		System.out.println("Short Value: "+i2.shortValue());

		System.out.println("Converting Integer Into String: ");
		int i3 = 43;
		String str2 = Integer.toString(i3);
		System.out.println("String Conversion: "+str2);
	}
	
}