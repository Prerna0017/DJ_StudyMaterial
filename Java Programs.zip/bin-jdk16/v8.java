import java.util.Vector;
import java.util.Scanner;
public class v8
{
	public static void main(String args[])
	 {	
	Scanner sc = new Scanner(System.in);
		//Scanner input = new Scanner(System.in);
	
      	Vector vec = new Vector(10);
      	vec.add(4);
      	vec.add(1);
      	vec.add(7.98f);
      	vec.add(23.9f);
      	vec.add('A');
      	vec.add('B');
      	vec.add("Prerna");
      	vec.add("Jadhav");

      	System.out.println("The Vector elements are: " + vec);

	for (int i = 0; i <= vec.size() - 1; i++)
	{
      		System.out.println("The element at Index "+i+" is: "+ vec.elementAt(i));
   	}

      	System.out.println("Enter 1 to search integer");
	System.out.println("Enter 2 to search float");
	System.out.println("Enter 3 to search Character");
	System.out.println("Enter 4 to search String");
   	int ch = sc.nextInt();

	switch(ch)
	{
	case 1:
	
		System.out.print("Enter the Integer element to be searched in the Vector: ");
		int intInput = sc.nextInt();
		System.out.println("Vector contains "+intInput+" :" + vec.contains(intInput));
		System.out.println("The index of element "+intInput+" in Vector is: " + vec.indexOf(intInput));
		break;
	
	case 2:
	
		
		System.out.print("Enter the Float element to be searched in the Vector: ");
		float floatval = sc.nextFloat();
		System.out.println("Vector contains "+floatval+" :" + vec.contains(floatval));
		System.out.println("The index of element "+floatval+" in Vector is: " + vec.indexOf(floatval));
		break;
	
	case 3:
	
		System.out.print("Enter the Character element to be searched in the Vector: ");
		char chInput = sc.next().charAt(0);
		System.out.println("Vector contains "+chInput+" :" + vec.contains(chInput));
		System.out.println("The index of element "+chInput+" in Vector is: " + vec.indexOf(chInput));
		break;
	
	case 4:
	
		System.out.print("Enter the String element to be searched in the Vector: ");
		String str2Input = sc.nextLine();
		String strInput = sc.nextLine();
		System.out.println("Vector contains "+strInput+" :" + vec.contains(strInput));
		System.out.println("The index of element "+strInput+" in Vector is: " + vec.indexOf(strInput));
		break;

	default:
		System.out.println("Invalid Choice");

	}

	vec.removeAllElements();
	System.out.println("Deleting All the Vector Elements");
     	System.out.println("The Vector elements are: " + vec);
	
	}
}