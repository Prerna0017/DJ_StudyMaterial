import java.util.Scanner;
class TerneryOp
{
  public static void main(String args[])
  {
    int num;
String result;
System.out.println("\nProgram to find a number is even or odd");
    System.out.println("\nEnter an Integer number:");
    Scanner input = new Scanner(System.in);
    num = input.nextInt();
result = (num % 2 == 0) ? "Even Number" : "Odd Number";
System.out.println("Entered number is an "+result);
  }
}
