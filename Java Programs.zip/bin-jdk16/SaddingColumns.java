import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;



public class SaddingColumns{
public static void main(String[] args) {
new SaddingColumns();
}
public SaddingColumns(){
JFrame frame = new JFrame("Sadding Columns in a JTable");
JPanel panel = new JPanel();
String data[][] = {{"100","Vinod","programmer","5000"},
{"101","Deepak","Content Writer","20000"},
{"102","Noor","Techniqual Writer","30000"},{"104","Rinku","PHP programar","25000"}};
String col[] = {"Emp_Id","Emp_name","Emp_depart","Emp_sal"};
DefaultTableModel model = new DefaultTableModel(data,col);
//Setting the sadding in column
JTable table = new JTable(model){
public Component prepareRenderer (TableCellRenderer renderer, int index_row, int index_col){
Component comp = super.prepareRenderer(renderer, index_row, index_col);
//odd col index, selected or not selected
if(index_col % 2 != 0 && !isCellSelected(index_row, index_col)){
comp.setBackground(Color.lightGray);
}
else{
comp.setBackground(Color.white);
}
return comp;
}
};
JTableHeader header = table.getTableHeader();
header.setBackground(Color.yellow);
JScrollPane pane = new JScrollPane(table);
panel.add(pane);
frame.add(panel);
frame.setSize(460,200);
frame.setVisible(true);
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}