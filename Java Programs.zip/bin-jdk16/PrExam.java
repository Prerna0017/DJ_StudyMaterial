/* Write a program to perform following tasks:
    1. Calculate the length of the string
    2. Compare between the strings
    3. Concatenating strings
*/

import java.util.Scanner;

class PrExam{
    
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int ch = 0;
        String s1;
        String s2;
        System.out.println("Enter String1: ");
        s1 = sc.nextLine();
        System.out.println("Enter String2: ");
        s2 = sc.nextLine();
        
        System.out.println("\n1. Find Length\n2. Compare two Strings\n3. Concatenate Strings\n4. Enter new Strings\n5. Exit\n");
        while (ch != 5){
            System.out.println("\nEnter the Choice to perform operation on the string: ");
            ch = sc.nextInt();
            Scanner sc2 = new Scanner(System.in);
            switch(ch){
                case 1:
                System.out.println("Length of the Entered 1st String i.e., " + s1 + " is: "+s1.length());
                System.out.println("Length of the Entered 2nd String i.e., " + s2 + " is: "+s2.length());
                break;

                case 2:
                if (s1.compareTo(s2) == 0){
                    System.out.println("\nThe Entered Strings i.e., "+s1+" and "+s2+" Matches");
                }
                else{
                    System.out.println("\nThe Entered Strings i.e., "+s1+" and "+s2+" Doesnt Match");
                }
                break;

                case 3:
                System.out.println("Concatenated String = "+s1.concat(s2));
                break;

                case 4:
                s1 = "";
                s2 = "";
                System.out.println("Enter String1: ");
                s1 = sc2.nextLine();
                System.out.println("Enter String2: ");
                s2 = sc2.nextLine();
                break;

                case 5:
                System.exit(0);

                default:
                System.out.println("Invalid choice");
                break;
            }
        }
        sc.close();
    }
}