import java.util.Scanner;
class p4
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter First Name: ");
		String str1 = sc.nextLine();	//string input

		System.out.println("Enter Middle Name: ");
		String str2 = sc.nextLine();	//string input

		System.out.println("Enter Surname: ");
		String str3 = sc.nextLine();	//string input
		
		String s;
		s = str1.concat(str2);
		s = s.concat(str3);

		System.out.println("First Name: "+str1);
		System.out.println("Middle Name: "+str2);
		System.out.println("Surname: "+str3);
		System.out.println("Full Name: "+s);

	}
}

