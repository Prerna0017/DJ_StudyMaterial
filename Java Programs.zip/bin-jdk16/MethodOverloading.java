class Bank
{
	int getRateOfInterest()
	{
		return 10;
	}
}
class AXIS extends Bank
{
	int getRateOfInterest()
	{
		return 11;
	}
}
class ICICI extends Bank
{
	int getRateOfInterest()
	{
		return 12;
	}
}
class SBI extends Bank
{
	int getRateOfInterest()
	{
		return 9;
	}
}

class MethodOverriding
{
public static void main(String args[])
{
	AXIS a = new AXIS();
	ICICI i = new ICICI();
	SBI s = new SBI();

	System.out.println("AXIS Rate of Interest: "+a.getRateOfInterest());
	System.out.println("ICICI Rate of Interest: "+i.getRateOfInterest());
	System.out.println("SBI Rate of Interest: "+s.getRateOfInterest());
}
}