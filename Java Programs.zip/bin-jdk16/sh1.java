class room
{
	public float length,breadth,height;
	void get(float l,float b,float h)
	{
		length = l;
		breadth = b;
		height = h;	
	}

	void show()
	{
		System.out.println("Length: "+length);
		System.out.println("Breadth: "+breadth);
		System.out.println("Height: "+height);
	}
}
class calculate extends room
{
	float area,volume;
	
	void cal()
	{
		area = length*breadth;
		volume = length*breadth*height;
	}
		
	void show()
	{
		super.show();
		System.out.println("Area: "+area+" sq.units");
		System.out.println("Volume: "+volume+" cu.units");
	}
}

class sh1
{
	public static void main(String args[])
	{
		calculate c1 = new calculate( );
		c1.get(23,45,12);
		c1.cal();
		c1.show();
	}
}
