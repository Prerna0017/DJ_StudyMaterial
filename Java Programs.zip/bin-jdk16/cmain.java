import java.io.*;

class Complex
 {
    int real, imaginary;
    Complex()
    {
    }
    Complex(int tempReal, int tempImaginary)
    {
        real = tempReal;
        imaginary = tempImaginary;
    }
    Complex addComp(Complex C1, Complex C2)
    {
        Complex temp = new Complex();
        temp.real = C1.real + C2.real;
        temp.imaginary = C1.imaginary + C2.imaginary;
        return temp;
    }
}
 

public class cmain
{
    public static void main(String[] args) throws IOException
    {
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int tempReal_1,tempReal_2,tempImaginary_1,tempImaginary_2;
        System.out.println("Enter value for Real part for complex number1: ");
        tempReal_1=Integer.parseInt(br.readLine());
        System.out.println("Enter value for Imaginary part for complex number1: ");
        tempImaginary_1=Integer.parseInt(br.readLine());
        System.out.println("Enter value for Real part for complex number2: ");
        tempReal_2=Integer.parseInt(br.readLine());
        System.out.println("Enter value for Imaginary part for complex number2: ");
        tempImaginary_2=Integer.parseInt(br.readLine());

        Complex C1 = new Complex(tempReal_1,tempImaginary_1);
        System.out.println("Complex number 1 : "+ C1.real + " + "+ C1.imaginary+"i");
        Complex C2 = new Complex(tempReal_2,tempImaginary_2);
        System.out.println("Complex number 2 : "+ C2.real + " + "+ C2.imaginary+"i");
        Complex C3 = new Complex();
        C3 = C3.addComp(C1, C2);
 
        System.out.println("Sum of complex number : "+ C3.real + " + "+ C3.imaginary+"i");
    }
}