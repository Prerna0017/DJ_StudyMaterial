class book
{
	String Author, Title, Publisher;
	book ( String a,String t, String p)
	{
		Author = a;
		Title = t;
		Publisher = p;
	}
	
	void show()
	{
		System.out.println("Author of the Book: "+Author);
		System.out.println("Title of the Book: "+Title);					System.out.println("Publisher of the Book: "+Publisher);
	}	
}
class bookInfo extends book
{
	float Price;
	int Stops;
	bookInfo(String a,String t, String p,float pr,int s  )
	{
		super(a,t,p);
		Price = pr;
		Stops = s; 
	}

	void show()
	{
		super.show();
		System.out.println("Price of the Book: "+Price);
		System.out.println("Stops of the Book: "+Stops);	
	}
}
class bookDetails
{
	public static void main(String args[])
	{
		bookInfo b1 = new bookInfo("Balaguruswamy","Java Programming","Tata McGraw",234.89f,10);
		b1.show();

		bookInfo b2 = new bookInfo("Software Engineering","Roger Pressman","Tata McGraw",344.09f,10);
		b2.show();

		bookInfo b3 = new bookInfo("Balaguruswamy","C Programming","Tata McGraw",234.89f,30);
		b2.show();
	}
}