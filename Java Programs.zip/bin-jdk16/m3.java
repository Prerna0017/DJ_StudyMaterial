
class animal
{
	void move()
	{
		System.out.println("Different Animals Move in Different Ways");
	}
}	//end of parent class

class dog extends animal
{
	String name = "Tommy";
	void move()
	{
		super.move();
		System.out.println(name+" Walks with his 4 legs");
	}		
}	//end of child class

class m3
{
	public static void main(String args[])
	{
		dog d = new dog();
		d.move();
	}
}