import java.io.*;
class Mobile
{
	BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
	
	String company_name;
	float screen_size;

	void getdata() throws IOException
	{
		System.out.print("Enter Company Name: ");
		company_name = br.readLine();
		System.out.print("Enter Screen Size: ");
		screen_size = Float.parseFloat(br.readLine());
	}
	
	void display()
	{
		System.out.println("Company Name: "+company_name);
		System.out.println("ScreenSize: "+screen_size+" cms");
	}

	public static void main(String args[]) throws IOException
	{
		Mobile m[] = new Mobile[5];
		for(int i=0; i<5;i++)
		{
			m[i] = new Mobile();
		}
		for(int i=0; i<5;i++)
		{
			m[i].getdata();
		}
		for(int i=0; i<5;i++)
		{
			m[i].display();
		}
	}
}
