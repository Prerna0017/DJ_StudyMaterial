import java.util.Scanner;
class newfor
{
	public static void main(String args[])
	{
		Scanner input = new Scanner(System.in);	

		System.out.print("Enter the Size of the array: ");	
		int size = input.nextInt();

		int arr[]= new int [size];
		System.out.println("Length of Array: "+arr.length);

		System.out.print("Enter "+size+" Array Elements: ");

		for(int i=0;i<=arr.length-1;i++)
			{    
				arr[i]= input.nextInt();
			}    

		System.out.println("");
		System.out.println("Printing Array Elements:");
		for(int a:arr)
		{
			System.out.println(a);
		}
	}
}