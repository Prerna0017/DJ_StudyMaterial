import java.lang.*;
import java.io.*;
import java.util.*;

public class testing { 
    public static void main(String[] args) {
        int zero[] = new int[10];
        int zeros = 0;
        System.out.println("Hello World");
        String str = "10100010000010";
        char[] ch = new char[str.length()];
        for (int i = 0; i < str.length(); i++) {
            ch[i] = str.charAt(i);
        }
        for (char c : ch) {
            int n = Integer.valueOf(c);
            if (n == 0) {
                zeros++;
            } else if (n == 1) {
                ArrayList<Integer> arrayList = new ArrayList<Integer>(Arrays.asList(zero));
                arrayList.add(zeros);
                zero = arrayList.toArray(zero);
                zeros = 0;
            }
        }
        System.out.println(ch);
    }
}
