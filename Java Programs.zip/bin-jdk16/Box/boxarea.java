package Box;
public class boxarea
{
	int l,b,h;
	public boxarea(int l1,int b1, int h1)
	{
		l = l1;
		b = b1;
		h = h1;
	}
	public void display()
	{
		int vol = l*b*h;
		System.out.println("Volume: "+vol);
	}
}