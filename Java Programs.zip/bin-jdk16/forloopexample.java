import java.io.*;
class forloopexample
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int a=5;
		System.out.println("Program to multiples of 5 between 20 and 70");
		//System.out.println("Enter the number to display the table: ");
		//a=Integer.parseInt(br.readLine());
		for (int i=1;i<=20;i++)
		{
			if (a*i>=20 && a*i<=70)
			{
				System.out.println(a+" * "+i+" = "+a*i);
			}
		}
	}
}