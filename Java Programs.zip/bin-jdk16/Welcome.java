class Welcome
{
	public static void main(String args[])
	{
		System.out.println("Welcome");
		System.out.println("To");
		System.out.println("Java");
		System.out.println("Programming");
	}
}