/*Implement Single level Inheritance  ----   6marks  */
class person
{
	int age;
	String name;
	person(int a,String n)
	{
		age = a;
		name = n;
	}
	void display()
	{
		System.out.println("Age Of The Person: "+age);
		System.out.println("Name Of The Person: "+name);
	}
}	//end of parent class

class employee extends person
{
	String designation;
	float salary;
	employee(int a, String n, String d, float s)
	{
		super(a,n);
		designation = d;
		salary = s;
	}
	void display()
	{
		super.display();
		System.out.println("Designation Of The Person: "+designation);
		System.out.println("Salary Of The Person: "+salary);		
	}		
}	//end of child class

class heri1
{
	public static void main(String args[])
	{
		employee e1 = new employee (21,"Prerna","Manager",5800);
		e1.display();
		
		employee e2 = new employee (23,"Sanjay","Sales Manager",5800);
		e2.display();
		
		employee e3 = new employee (31,"Subhash","Marketing Manager",5800);
		e3.display();
	}
}