import java.util.*;
class temp
{
	public static void main (String args[])
	{
		Vector v = new Vector();
		System.out.println("Capacity: "+v.capacity());
		System.out.println("Size: "+v.size());
		v.addElement(new Integer (10));
		v.addElement(new Integer (20));
		v.addElement(new Float (2.709));
		v.addElement(new String("xyz"));
		v.addElement(new Double(22.646));
		v.addElement(new Character('P'));
		System.out.println(v);
		System.out.println("Capacity: "+v.capacity());
		System.out.println("Size: "+v.size());
		System.out.println("First element: "+v.firstElement());
		System.out.println("Last element: "+v.lastElement());
		System.out.println("element at index -2: "+v.elementAt(2));
		v.remove(22.646);
		System.out.println(v);
		v.remove(3);
		System.out.println(v);
		v.insertElementAt(60,2);
		System.out.println(v);
		System.out.println("Is 60 Present in vector : "+v.contains(60));
		System.out.println("Is 30 Present in vector : "+v.contains(30));
		v.removeAllElements();
		System.out.println(v);
	}
	
}