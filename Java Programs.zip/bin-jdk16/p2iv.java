class p2iv
{
	public static void main(String[] args) 
	{
		StringBuffer s = new StringBuffer("Welcome to Java Programming");
		System.out.println("String: "+s);
        		s.reverse();
       		System.out.println("Reversed: "+s);
   	}
}