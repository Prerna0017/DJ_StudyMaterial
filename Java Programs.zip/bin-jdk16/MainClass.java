/* Write a program to implement single and multilevel inheritance */

class Shape
{
    float l,b;
    void Area()
    {
        float area = l*b;
        System.out.println("Area: "+ area +" sq.units");
    }
}
class Rectangle extends Shape
{
    Rectangle(float len,float bdt)
    {
        l = len;
        b = bdt;
    }
    void Area(){
        super.Area();
    }
}
class MainClass{
    public static void main(String args[]) {
        Rectangle r1 = new Rectangle(20, 10);
        r1.Area();
    }
}