/* program to accept a password from user and throw authentication failure exception if the password is incorrect ---6m*/

import java.io.*;

class passException extends Exception 
{
	passException(String msg)
	{
		super(msg);
	}	
}

class passExcep
{
	public static void main(String args[]) 
	{
		String s1 = "admin";
		String s2;
		DataInputStream d = new DataInputStream(System.in);
		try
		{
			System.out.println("Enter Password: ");
			s2 = d.readLine();
			if(s1.equals(s2))
			{
				System.out.println("Password Valid ");
			}
			else
			{
				throw new passException("Authentication Failure: Invalid Password");
				
			}
		}
		catch (passException e)
		{
			System.out.println(e);
		}
		catch (IOException e)
		{
			System.out.println(e);
		}
	}
}