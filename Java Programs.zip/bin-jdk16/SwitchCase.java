import java.util.Scanner;
public class SwitchCase {

   public static void main(String args[]){
Scanner input = new Scanner(System.in);
      int num1;
      int num2;
int choice;

System.out.println("1.Addition");
System.out.println("2.Subtraction");
System.out.println("3.Multiplication");
System.out.println("4.Divison");

System.out.println("\nEnter your choice: ");
   
choice = input.nextInt();

System.out.println("\nEnter First Integer number:");   
num1 = input.nextInt();

System.out.println("Enter Second Integer number:");
num2 = input.nextInt();

    

      switch(choice)
      {
	 case 1:
	   System.out.println("\nAddition: "+(num1+num2));
	   break;
	 case 2:
	   System.out.println("\nSubtraction: "+(num1-num2));
	   break;
	 case 3:
	   System.out.println("\nProduct: "+(num1*num2));
	   break;
	 case 4:
                 System.out.println("\nRemainder: "+(num1/num2));
                 break;
	 default:
	 System.out.println("Invalid Choice");
      }
   }
}