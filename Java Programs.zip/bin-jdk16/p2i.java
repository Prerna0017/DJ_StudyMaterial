import java.util.Scanner;
class p2i
{
	public static void main (String[] args) 
 	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Any String: ");
		String str = sc.nextLine();	//string input

        		System.out.println("Enter the character to be searched: ");
		char ch = sc.next().charAt(0);	//character input
  		
		System.out.println("String is : "+str);
		System.out.println("Character is : "+ch);

		int firstIndex = str.indexOf(ch);	// Returns index of first occurrence of character.
		int lastIndex = str.lastIndexOf(ch);	    // Returns index of last occurrence specified character.
		
		if(firstIndex < 0 && lastIndex < 0)
		{
			System.out.println("Character "+ch+" not found in the string");
		}
		else
		{
			if(firstIndex == lastIndex )
			{
				System.out.println("Character "+ch+" occured only once at : "+firstIndex);
			}
			else
			{	
				System.out.println("First occurrence of char "+ch+ " is found at : " + firstIndex);
				System.out.println("Last occurrence of char "+ch+" is found at : " + lastIndex);
			}
		}
		
  	}
}