import newPackage.*;
class trial
{
	public static void main(String args[])
	{
		Task ob1 = new Task();
		ob1.display();
		ob1.add(10,20);
	}
}
