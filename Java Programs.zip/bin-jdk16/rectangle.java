class rectangle
{
	int length, breadth;
	rectangle()	//default constructor
	{
		length=10;
		breadth=5;
	}
	rectangle(int l, int b)    //parameterized constructor
	{
		length = l;
		breadth = b;
	}
	void display()	//method declaration
	{
		System.out.println("Length: "+length);
		System.out.println("Breadth: "+breadth);
	}
	void rectarea()	//to find area
	{	
		float area = length * breadth;
		System.out.println("AREA: "+area);
	}

public static void main(String args[])	//main class
{
	System.out.println("First Object");
	rectangle r1 = new rectangle();		//calling default constructor
	r1.display();
	r1.rectarea();
	
	System.out.println("Second Object");
	rectangle r2 = new rectangle(50,20);	//calling parameterized constructor
	r2.display();
	r2.rectarea();

	System.out.println("Third Object");
	rectangle r3 = new rectangle(100,30);	//calling parameterized constructor
	r3.display();
	r3.rectarea();
}
}





