import java.io.*;
class buffer
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		float DCN,MIC,SEN,JPR,GAD;
		System.out.println("Enter Marks for DCN: ");	
		DCN = Float.parseFloat(br.readLine());
		System.out.println("Enter Marks for MIC: ");	
		MIC = Float.parseFloat(br.readLine());
		System.out.println("Enter Marks for JPR: ");	
		JPR =Float.parseFloat(br.readLine());
		System.out.println("Enter Marks for SEN: ");	
		SEN = Float.parseFloat(br.readLine());
		System.out.println("Enter Marks for GAD: ");	
		GAD = Float.parseFloat(br.readLine());
		float percentage=(DCN+MIC+JPR+SEN+GAD)/5;
		System.out.println("Percentage: "+percentage+"%");
	}
}