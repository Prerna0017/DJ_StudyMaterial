
import java.io.IOException;
import java.util.Scanner;

abstract class Shapes{
    float dim1,dim2;
    double area;
    abstract void disp();
    abstract void area();
}
class rectangle extends Shapes{
    Scanner sc = new Scanner(System.in);
    void getd(){
        System.out.println("Enter the 1st Dimension: ");
        dim1 = sc.nextFloat();
        System.out.println("Enter the 2nd Dimension: ");
        dim2 = sc.nextFloat();
    }
    
    void disp() {
        System.out.println("Dimension1 = "+dim1);
        System.out.println("Dimension2 = "+dim2);
    }
    void area() {
        area = dim1 * dim2;
        System.out.println("Area of the Rectangle = "+area);
    }
}
class triangle extends Shapes{
    Scanner sc = new Scanner(System.in);
    void getd(){
        System.out.println("Enter the 1st Dimension: ");
        dim1 = sc.nextFloat();
        System.out.println("Enter the 2nd Dimension: ");
        dim2 = sc.nextFloat();
    }
    
    void disp() {
        System.out.println("Dimension1 = "+dim1);
        System.out.println("Dimension2 = "+dim2);
    }
    void area() {
        area = 0.5 * dim1 * dim2;
        System.out.println("Area of the Triangle = "+area);
    }
}
public class dimensions {
    public static void main(String args[])throws IOException{
        rectangle r = new rectangle();
        r.getd();
        r.disp();
        r.area();
        triangle t = new triangle();
        t.getd();
        t.disp();
        t.area();
    }
}
