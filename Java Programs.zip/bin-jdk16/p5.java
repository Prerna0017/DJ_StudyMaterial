import java.util.Scanner;
class p5
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Case is IGNORED to check the string is Palindrome or not");

		System.out.println("Enter Any String: ");
		String str1 = sc.nextLine();	//string input

		String rev = "";

		//creating character array named char_array to convert String into character array
		char[] char_array = str1.toCharArray();
		
		for ( int i = char_array.length - 1; i >= 0; i--)
		{
			rev = rev + str1.charAt(i);
			
		}
		System.out.println(rev);
		if(str1.equalsIgnoreCase(rev))
		{
			System.out.println("Entered String is A Palindrome");
		}
		else
		{				
			System.out.println("Entered String is Not A Palindrome");
		}
	}
}

