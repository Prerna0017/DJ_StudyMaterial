package Add;
public class add2
{
	int n1,n2;
	public add2(int a,int b)
	{
		n1 = a;
		n2 = b;
	}
	public void display()
	{
		int sum = n1+n2;
		System.out.println("SUM: "+sum);
	}
}