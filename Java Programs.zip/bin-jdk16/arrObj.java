/* Define a class Mobile with data members ‘company_name’ and ‘screen_size’. Initialize and 
display values of data members for five mobiles using array of objects.  */
import java.io.*;
class Mobile
{
	BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
	
	String company_name;
	float screen_size;

	void getdata()
	{
		System.out.print("Enter Company Name: ");
		company_name = br.readLine();
		System.out.print("Enter Screen Size: ");
		screen_size = Float.parseFloat(br.readLine());
	}
	
	void display()
	{
		System.out.println("Company Name: "+company_name);
		System.out.println("ScreenSize: "+screen_size+" cms");
	}
}
class arrObj
{
	public static void main(String args[]) throws IOException
	{
		Mobile m[] = new Mobile[5];
		for(int i=0; i<5;i++)
		{
			m[i].getdata();
		}
		for(int i=0; i<5;i++)
		{
			m[i].display();
		}
	}
}