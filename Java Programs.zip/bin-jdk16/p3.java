/*Program to accept a string from the console and count numbers of vowels, constants, digits, tabs and blank spaces in a string.*/

import java.util.Scanner;
class p3
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Any String: ");
		String str1 = sc.nextLine();	//string input

		int digit_counter = 0;
		int l = str1.length();
		char ch;
		for ( int i = 0; i<l; i++)
		{
			ch=str1.charAt(i);
			if (ch >= '0' && ch <= '9')
			 {
				digit_counter++;
			}
		}
		System.out.println("The number of Digits is: "+digit_counter);
		int bspace_counter = 0;
		for ( int i = 0; i<l; i++)
		{
			ch=str1.charAt(i);
			if (ch == ' ')
			 {
				bspace_counter++;
			}
		}
		System.out.println("The number of Blank Spaces  is: "+bspace_counter);
		int vowel_counter = 0;
		int consonants_counter = 0;
		for ( int i = 0; i<l; i++)
		{
			ch=str1.charAt(i);
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
			 {
				 vowel_counter++;
			}
			else
			{
				consonants_counter++;
			}
		}
		System.out.println("The number of Vowels  is: "+ vowel_counter);
		System.out.println("The number of Consonants  is: "+ consonants_counter);
		int tab_counter = 0;
		for ( int i = 0; i<l; i++)
		{
			ch=str1.charAt(i);
			if (ch == '\t')
			 {
				tab_counter++;
			}
		}
		System.out.println("The number of tabs is: "+tab_counter);

   	}
}