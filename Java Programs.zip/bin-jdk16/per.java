import java.util.Scanner;
class per
{
	public static void main(String args[])
	{
		Scanner input = new Scanner(System.in);
		float DCN,MIC,SEN,JPR,GAD;
		System.out.println("Enter Marks for DCN: ");		
		DCN = input.nextInt();
		System.out.println("Enter Marks for MIC: ");		
		MIC = input.nextInt();
		System.out.println("Enter Marks for JPR: ");		
		JPR = input.nextInt();
		System.out.println("Enter Marks for SEN: ");		
		SEN = input.nextInt();
		System.out.println("Enter Marks for GAD: ");		
		GAD = input.nextInt();
		float percentage=(DCN+MIC+JPR+SEN+GAD)/5;
		System.out.println("Percentage: "+percentage+"%");
	}
}