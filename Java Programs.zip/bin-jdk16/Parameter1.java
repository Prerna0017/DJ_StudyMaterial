import java.awt.*;
import java.applet.*;

public class Parameter1 extends Applet
{
	String val1,val2,ans;
	public void init()
	{
		val1 = Integre.parseInt(getParameter("x"));
		val2 = Integre.parseInt(getParameter("y"));
		ans = val1+val2;

	}
	public void paint(Graphics g)
	{
		g.drawString(str,100,200);
	}
}


/*
<APPLET CODE = Parameter1 WIDTH = 500 HEIGHT = 500>
<PARAM name = x value = 10>
<PARAM name = y value = 20>
</APPLET> 
*/