class student
{
	String name;
	int rollno , marks1, marks2;

	void getdata(String n, int r, int m1, int m2)
	{
		name = n;
		rollno = r;
		marks1 = m1;
		marks2 = m2;
	}
	void show()
	{
		System.out.println("Name of the Student: "+name);
		System.out.println("Rollno. of the Student: "+rollno);
		System.out.println("Marks of Subject1: "+marks1);
		System.out.println("Marks of Subject2: "+marks2);
	}
}	//parent1

interface exam
{
	void percentage();
}	//parent 2

class Result extends student implements exam
{
	float total;
	void display()
	{
		super.show();
		total = marks1+ marks2;
		System.out.println("Total Marks: "+total);
	}

	public void percentage()
	{
		float per = total * 100 / 200;
		System.out.println("Percentage: "+per);
	}
}	//end of child class

class classresult
{
	public static void main (String args[])
	{
		Result obj = new Result();
		obj.getdata("Prerna",89,78,90);
		obj.display();
		obj.percentage();
	}

}