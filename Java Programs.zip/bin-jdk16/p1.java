import  java.io.*;
class p1 
{
	// Function to print all possible substring
	public static void SubString(String str, int n)
		{
			int count = 1;
			for (int i = 0; i < n; i++)
			{
				for (int j = i+1; j <= n; j++)
				{
					System.out.println("Subtring No."+(count)+": "+str.substring(i, j));
					count++;
				}
			}
		}
    		public static void main(String[] args) throws IOException
   		{
			DataInputStream d=new DataInputStream (System.in);
			System.out.println("Enter any String to get all possible substrings : ");
			String str =  d.readLine();
        			SubString(str, str.length());
   		}
}