import Box.*;
class pack2
{
	public static void main(String args[])
	{
		boxarea b = new boxarea(2,3,4);
		b.display();
	}
}