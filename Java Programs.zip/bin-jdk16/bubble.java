import java.util.Scanner;
class bubbleSorting
{
	void bubbleSort(int arr[])
    	{
       	int n = arr.length;
        	for (int i = 0; i < n-1; i++)
	{	
            		for (int j = 0; j < n-i-1; j++)
		{
                			if (arr[j] > arr[j+1])
                			{
                    				// swap arr[j+1] and arr[j]
                    				int temp = arr[j];
                    				arr[j] = arr[j+1];
                   				arr[j+1] = temp;
                			}
		}
	}
	for(int i=0;i<=arr.length-1;i++)
	{    
		System.out.println(arr[i]);
	}   
	}	
}
class bubble
{
	public static void main(String args[])
	{
	bubbleSorting ob = new bubbleSorting();
	
	Scanner input = new Scanner(System.in);	

	int arr[]= new int [10];

	System.out.println("Enter 10 Array Elements: ");
	for(int i=0;i<=arr.length-1;i++)
		{    
			arr[i]= input.nextInt();
		}    
	
	System.out.println("");

	System.out.println("Printing Array Elements in Ascending Order (using BUBBLE SORT):");
	ob.bubbleSort(arr);
	}

}