import java.io.*;
class Employee
{
	BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
	
	int empid;
	String name;
	float salary;

	void getdata() throws IOException
	{
		System.out.print("Enter Employee ID: ");
		empid = Integer.parseInt(br.readLine());
		System.out.print("Enter Employee Name: ");
		name = br.readLine();
		System.out.print("Enter Employee Salary: ");
		salary = Float.parseFloat(br.readLine());
		System.out.println(" ");
	}
	
	void display()
	{
		System.out.println("Employee ID: "+empid);
		System.out.println("Employee Name: "+name);
		System.out.println("Employee Salary: "+salary);
		System.out.println(" ");
	}

	public static void main(String args[]) throws IOException
	{
		Employee e[] = new Employee[5];
		for(int i=0; i<5;i++)
		{
			e[i] = new Employee();
		}
		for(int i=0; i<5;i++)
		{
			e[i].getdata();
		}
		for(int i=0; i<5;i++)
		{
			e[i].display();
		}
	}
}
