class Cube
{
	float l,b,h;
	
	Cube()	//default constructor
	{
		l = 10;
		b = 10;
		h =10;	
	}
	Cube(float lt,float bt,float ht)	//parameterized constructors (for float values)
	{
		l = lt;
		b = bt;
		h = ht;
	}
	Cube(int lt,int bt,int ht)	//parameterized constructors (for int values)
	{
		l = lt;
		b = bt;
		h = ht;
	}
	void display()
	{
		System.out.println("Length :"+l+" units");
		System.out.println("Breadth: "+b+" units");
		System.out.println("Height: "+h+" units");
	}
	void volume()
	{
		float vol;
		vol = l * b* h;
		System.out.println("Volume of the cube: "+vol+" cubic units");
	}

	public static void main(String args[])
	{
		Cube cube1 = new Cube();
		cube1.display();
		cube1.volume();

		Cube cube2 = new Cube(10.22f,11.2f,6.09f);
		cube2.display();
		cube2.volume();

		Cube cube3 = new Cube(10,7,9);
		cube3.display();
		cube3.volume();
	}	
}