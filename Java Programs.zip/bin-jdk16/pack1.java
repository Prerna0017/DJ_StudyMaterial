import math_s.*;
class pack1
{
	public static void main(String args[])
	{
		addition a = new addition();
		a.getdata(23,67);
		a.result();

		subtraction s = new subtraction();
		s.getdata(90,9);
		s.result();
	}
}