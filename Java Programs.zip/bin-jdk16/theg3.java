/* Program to create two threads such that one thread prints even numbers and another prints odd numbers from 1 - 10*/

class even extends Thread
{

	public void run()
	{
		System.out.println("Even Thread Started");
		for(int i = 0; i<=10; i++)
		{
			System.out.println("Even:"+i);
		}
		System.out.println("Even Thread Ends");
	}

}

class odd extends Thread
{

	public void run()
	{
		System.out.println("Odd Thread Started");
		for(int i = 1; i<=10; i=i+2)
		{
			System.out.println("Odd: "+i);
		}
		System.out.println("Odd Thread Ends");
	}

}

class theg3
{
	public static void main(String args[])
	{		
	System.out.println("Main Thread Started");

	new even().start();
	new odd().start();
/*
	even e  = new even();
	odd o = new odd();
	e.start();
	o.start();
*/
	System.out.println("Main Thread Ended");
	}
}