import myInstitute.*;
class pr20
{
	public static void main(String args[])
	{
		department d = new department();
		d.display();
	}
}
