class demo
{
public static void main(String args[])
{
int x=3;
int s = x++ +3;
System.out.println(s);
}
}