import java.io.*;
public class File5
{
   public static void main(String[] args) throws IOException 
   {
      File fsrc=new File("text1.txt");         
      File fdes=new File("text2.txt"); 
      if (!fsrc.exists()) {
			try {
				fsrc.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

      if (!fdes.exists()) {
			try {
				fdes.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}  
      FileReader fr=new FileReader(fsrc);          
      BufferedReader br=new BufferedReader(fr);  
      FileWriter fw= new FileWriter(fdes);      
      String s=null;
      while((s=br.readLine())!=null)             
      {
         fw.write(s);
         fw.write("\n");
         fw.flush();
      }
         fw.close();
   }
}