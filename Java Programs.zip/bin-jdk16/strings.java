import java.io.*;
class strings
{
	public static void main(String args[])
	{
		String s1 = "JAVA";		//string literal
		String s2 = new String("programming");	//using new keyword
		String s3 = "date";
		String s4 = "	DATE"	;
		String s5 = "Welcome to java";
		System.out.println("s1: "+s1);
		System.out.println("s2: "+s2);
		System.out.println("s3: "+s3);
		System.out.println("s4: "+s4);
		System.out.println("s5: "+s5);

		//String methods
		System.out.println("Lowercase: " + s1.toLowerCase());
		System.out.println("Uppercase: " + s1.toUpperCase());
		System.out.println("Replacing E to A: " + s3.replace('e','a'));
		System.out.println("Trim Removes Spaces: " + s4.trim());	//removes white space at beginning and end
		System.out.println("Check Equality: " + s1.equals(s2));
		System.out.println("Check Equality(Ignore Case): " + s3.equalsIgnoreCase(s4));	//to ignore cases while checking equality
		System.out.println("Length of String s1: " + s1.length());
		System.out.println("Character at index 3: " + s1.charAt(3));
		System.out.println("Compare to method: " + s3.compareTo(s4));	//return 3 output i.e +ve, -ve or 0
		System.out.println("Concatenation: " + s1.concat(s2));	//joins two string
		System.out.println("Substrings to nth position: " + s1.substring(1));
		System.out.println("Substrings to nth position: " + s1.substring(2));
		System.out.println("Substrings from nth position to mth position: " + s1.substring(0,3));
		System.out.println("Index of character v: " + s1.indexOf('V'));
		System.out.println("Index of character a: " + s1.indexOf('A'));
		System.out.println("Index of character a at 2nd occurence: " +s1.indexOf('A',2));
		System.out.println("Index of last occurence of a character  : "+s1.lastIndexOf('A'));
		System.out.println("Index of character a: " + s1.indexOf('A'));
		System.out.println("S5 starts with Welcome?: " + s5.startsWith("Welcome"));
		System.out.println("S5 ends with Java?: " + s5.endsWith("java"));
	}	
}







