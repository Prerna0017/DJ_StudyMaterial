import java.util.Scanner;
class Addno
{
  public static void main(String args[])
  {
    int a,b;
    
    Scanner input = new Scanner(System.in);
    
    System.out.println("Enter First Integer number:");
    a = input.nextInt();
    
    System.out.println("Enter First Integer number:");
    b = input.nextInt();
    
    if ( a>10 && b >10 ){
        System.out.println("Entered number is greater than 10");
        System.out.println("Sum = "+ (a+b));
    }
     else
        System.out.println("Entered Number are less than 10");
  }
}
