package newPackage;
public class Task
{
	public void display()
	{
		System.out.println("Welcome to newPackage");
	}

	public void add(int a,int b)
	{
		System.out.println(a+b);
	}
}