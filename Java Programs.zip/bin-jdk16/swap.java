import java.io.*;
class swap
{
	public static void main(String prerna[]) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int a,b;
		System.out.println("Enter value for a: ");
		a=Integer.parseInt(br.readLine());
		System.out.println("Enter value for b: ");
		b=Integer.parseInt(br.readLine());
		System.out.println("Before Swapping");
		System.out.println("Value of a: "+a);
		System.out.println("Value of b: "+b);
		int c=a;
		a=b;
		b=c;
		System.out.println("After Swapping");
		System.out.println("Value of a: "+a);
		System.out.println("Value of b: "+b);
	}
}