import java.io.FileWriter;   
import java.io.IOException; 

class FileCmd{  

public static void main(String abcd[]){  

System.out.println("Your first argument is: "+abcd[0]); 

try {
        FileWriter myWriter = new FileWriter("Command_line.txt",true);
            myWriter.write("Command Line : "+abcd[0]);
            myWriter.close();
            System.out.println("Command Line stored... sucssefully..!!");
          } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
}
}
}