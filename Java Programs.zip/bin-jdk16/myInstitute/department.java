package myInstitute;
public class department
{
	String n = "Sachin";	
	public void display(){
		System.out.println("Staff name: "+n);
	}
}