class fibo
{
		public static void main(String args[]) 
		{
			int firstnum=0;
			int secondnum=1;
			int thirdnum=0;
			System.out.println(firstnum);
			System.out.println(secondnum);
			for (int i=1;i<=10;i++)
			{
				thirdnum=firstnum + secondnum;
				System.out.println(thirdnum);		
				firstnum=secondnum;
				secondnum=thirdnum;		
			}

		}

}