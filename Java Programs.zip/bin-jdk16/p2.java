import java.util.Scanner;
class p2
{

		static void p2i()
		{
			Scanner sc = new Scanner(System.in);

			System.out.println("Enter Any String: ");
			String str = sc.nextLine();	//string input

        			System.out.println("Enter the character to be searched: ");
			char ch = sc.next().charAt(0);	//character input
  		
			System.out.println("String is : "+str);
			System.out.println("Character is : "+ch);

			int firstIndex = str.indexOf(ch);	// Returns index of first occurrence of character.
			int lastIndex = str.lastIndexOf(ch);	    // Returns index of last occurrence specified character.
		
			if(firstIndex < 0 && lastIndex < 0)
			{
				System.out.println("Character "+ch+" not found in the string");
			}
			else
			{
				if(firstIndex == lastIndex )
				{
					System.out.println("Character "+ch+" occured only once at : "+firstIndex);
				}
				else
				{	
					System.out.println("First occurrence of char "+ch+ " is found at : " + firstIndex);
					System.out.println("Last occurrence of char "+ch+" is found at : " + lastIndex);
				}
			}
		}

		static void p2ii ()
		{
			Scanner sc = new Scanner(System.in);

			System.out.println("Enter Any String: ");
			String str = sc.nextLine();	//string input

			System.out.println("Enter Any Substring to be searched: ");
			String substr = sc.nextLine();	//string input

			int lastIndex = str.lastIndexOf(substr);
			if(lastIndex == - 1)
			{
         				System.out.println("Hello not found");
      			}
			else
			{
         				System.out.println("Last occurrence of "+substr+" is at index "+ lastIndex);
     	 		}
   		}

		static void p2iii()
		{
			Scanner sc = new Scanner(System.in);

			System.out.println("Enter String 1: ");
			String str1 = sc.nextLine();	//string input

			System.out.println("Enter String 2: ");
			String str2 = sc.nextLine();	//string input

			int c = str1.compareTo(str2);
			if (c != 0)
			{
				System.out.println("The Strings Are Not EQUAL");
			}
			else
			{
				System.out.println("The Strings Are EQUAL");
			}
   		}

		static void p2iv()
		{
			Scanner sc = new Scanner(System.in);

			System.out.println("Enter String : ");
			String str1 = sc.nextLine();	//string input

			StringBuffer s = new StringBuffer(str1);
			//StringBuffer s = new StringBuffer("Welcome to Java Programming");
			System.out.println("String: "+s);
        			s.reverse();
       			System.out.println("Reversed: "+s);
   		}

	public static void main (String[] args) 
 	{
		Scanner input = new Scanner(System.in);
	
		int choice,op=1;

		System.out.println("1.To search a word inside a string");
		System.out.println("2. To search the last position of a substring");
		System.out.println("3. To compare two strings");
		System.out.println("4. To print reverse of string");

		System.out.println("\nEnter your choice: ");
   		choice = input.nextInt();

    		switch(choice)
      		{
	 		case 1:
	   		p2i();
	   		break;
	 		case 2:
	   		p2ii();
	   		break;
	 		case 3:
	   		p2iii();
	   		break;
	 		case 4:
                 			p2iv();
                 			break;
	 		default:
	 		System.out.println("Invalid Choice");
      		}	
  	}
}