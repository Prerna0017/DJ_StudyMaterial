/* /write a program which throws an exception as "Invalid age" if user enters negative value for variable age   */

import java.io.*;

class ageException extends Exception 
{
	ageException(String msg)
	{
		super(msg);
	}	
}

class excep
{
	public static void main(String args[]) 
	{
		int age;
		DataInputStream d = new DataInputStream(System.in);
		try
		{
			System.out.println("Enter Age: ");
			age = Integer.parseInt(d.readLine());
			if(age > 18)
			{
				System.out.println("Age is Appropriate. ");
			}
			else
			{
				throw new ageException("Your Age is Invalid");
				
			}
		}
		catch (ageException e)
		{
			System.out.println(e);
		}
		catch (IOException e)
		{
			System.out.println(e);
		}
	}
}