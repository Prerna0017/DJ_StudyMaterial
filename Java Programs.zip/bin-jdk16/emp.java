/* Write a java program to define a class employee with the data members emp_id, emp_name, dept. Initialize the data members and display value of data members for two objects */

class emp
{
	int emp_id;
	String emp_name,dept;
	
	emp(int id, String m, String d)
	{
		emp_id = id;
		emp_name = m;
		dept = d;
	}

	void display()
	{
		System.out.println(" Employee ID: "+emp_id);
		System.out.println(" Employee Name: "+emp_name);
		System.out.println(" Employee Department: "+dept);
		System.out.println("");
	}	

	public static void main( String args[])
	{
		emp e1 = new emp (23918, "Prerna", "Marketing");
		e1.display();
		emp e2 = new emp (42135, "Kriti", "Sales");
		e2.display();
	}
}