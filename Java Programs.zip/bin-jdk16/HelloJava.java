import java.awt.*;
import java.applet.*;
public class HelloJava extends Applet
{
	public void paint (Graphics g)
	{
		g.drawString("HelloJava", 11,110);
	}
}
/*  <applet code = "HelloJava.class" width=200 heigth=200>
      </applet> */