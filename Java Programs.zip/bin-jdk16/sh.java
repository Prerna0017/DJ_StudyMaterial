class wrapperdemo
{
	public static void main(String args[])
	{
		//convert  string into integer using wrapper class object
		String str = "23";
		Integer i = Integer.valueOf(str);
		System.out.println("The integer value: "+i);
		Float f = Float.valueOf(str);
		System.out.println("The float value: "+f);

		//convert integer object value into primitive data type byte
	}
}