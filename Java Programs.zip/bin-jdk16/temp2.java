import java.util.*;
class temp2
{
	public static void main (String args[])
	{
		Vector v = new Vector();
		System.out.println("Capacity: "+v.capacity());
		System.out.println("Size: "+v.size());
		v.add (10);
		v.add(20);
		v.add(2.709);
		v.add("xyz");
		v.add(22.646);
		v.add('P');
		System.out.println(v);
		System.out.println("Capacity: "+v.capacity());
		System.out.println("Size: "+v.size());
		System.out.println("First element: "+v.firstElement());
		System.out.println("Last element: "+v.lastElement());
		System.out.println("element at index -2: "+v.elementAt(2));
		v.remove(22.646);
		System.out.println(v);
		v.remove(3);
		System.out.println(v);
		v.insertElementAt(60,2);
		System.out.println(v);
		System.out.println("Is 60 Present in vector : "+v.contains(60));
		System.out.println("Is 30 Present in vector : "+v.contains(30));
		v.removeAllElements();
		System.out.println(v);
	}
	
}