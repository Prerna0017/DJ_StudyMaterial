/* WRITE A PROGRAM TO CREATE A VECTOR WITH 7 ELEMENTS AS (10,30,50,20,40,10,20) REMOVE THE ELEMENTS AT 3RD AND 4TH POSITION. INSERT NEW ELEMENT AT 3RD POSITION, DISPLAY THE ORIGINAL AND CURRENT SIZE OF THE VECTOR -------8 MARKS */

import java.util.*;
class vp
{
	public static void main(String args[])
	{
		Vector v = new Vector(7);
		System.out.println("Size of the vector: "+v.size());
		v.addElement (new Integer(10));
		v.addElement (new Integer(30));
		v.addElement (new Integer(50));
		v.addElement (new Integer(20));
		v.addElement (new Integer(40));
		v.addElement (new Integer(10));
		v.addElement (new Integer(20));
		System.out.println(v);
		v.removeElementAt(4);
		v .removeElementAt(4);
		System.out.println(v);
		System.out.println("Size of the vector: "+v.size());
	}
}