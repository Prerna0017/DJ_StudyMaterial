import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
 
public class ScrollPaneDemo {
    JFrame mainFrame;
    JPanel controlPanel;

    public static void main(String[] args){
        ScrollPaneDemo  scrollPaneDemo = new ScrollPaneDemo();      
        scrollPaneDemo.scrollPane();
     }
  
     ScrollPaneDemo(){
        mainFrame = new JFrame("Java ScrollPane Program");
        mainFrame.setSize(400,400);
        mainFrame.setLayout(new GridLayout(3, 1));
        
        mainFrame.addWindowListener(new WindowAdapter() {
           public void windowClosing(WindowEvent windowEvent){
              System.exit(0);
           }        
        });   
  
        controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());
  
        mainFrame.add(controlPanel);
        mainFrame.setVisible(true);  
     }
   
      void scrollPane(){
      JTextArea outputTextArea = new JTextArea("",5,20);
      JScrollPane scrollPane = new JScrollPane(outputTextArea);    
      
      controlPanel.add(scrollPane);
      mainFrame.setVisible(true);  
   }   
}