import java.io.*;
class factorial
{
	public static void main(String prerna[]) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int num,fact=1;
		int i=1;
		System.out.println("Enter a number to find its factorial: ");
		num=Integer.parseInt(br.readLine());
		while(i<=num)
		{
			fact = fact * i;
			i++;
		}
		System.out.println("Factorial of "+num+" is: "+fact);
	}
}