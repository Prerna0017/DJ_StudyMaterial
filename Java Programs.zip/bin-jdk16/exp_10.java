
class student
{
	int rollno;
	String name;
	String branch;

	student(int r, String n, String b)
	{
		rollno = r;
		name = n;
		branch = b;
	}

	void display()
	{
		System.out.println("Roll No.: " + rollno);
		System.out.println("Name: " + name);
		System.out.println("Branch: "+branch);
	}
}		//end of class student

class exp_10
{
	public static void main (String args[]) 
	{
		student s1 = new student (31,"Prerna","Computers");
		s1.display();

		student s2 = new student (32,"Janhavi","Computers");
		s2.display();
	}
}