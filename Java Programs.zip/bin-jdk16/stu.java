/* Program to define a class student with four data members such as name, rollno, sub1, sub2. Define appropriate methods to initialize and display the value of data members and also calculate total marks and percentage scored by the student.  */

class student
{
	int rollno;
	float sub1, sub2;
	String name;

	student(int r, String m, float s1, float s2)
	{
		rollno = r;
		name = m;
		sub1 = s1;
		sub2 = s2;
	}

	void display()
	{
		System.out.println("Roll No.: " + rollno);
		System.out.println("Name: " + name);
		System.out.println("Subject 1: " + sub1);
		System.out.println("Subject 2: " + sub2);
	}

	void calculate()
	{
		float total = sub1 + sub2;
		System.out.println("Total Marks: " + total);
		float per = (total/200) *100;
		System.out.println("Percentage: " + per + "%");
		System.out.println();
	}
}		//end of class student

class stu
{
	public static void main (String args[])
	{
		student stud1 = new student (31, "Prerna" , 89.54f, 80.78f);
		stud1.display();
		stud1.calculate();

		student stud2 = new student (32, "Janhavi" , 86.21f, 79.08f);
		stud2.display();
		stud2.calculate();
	}
}		//end of second class stu