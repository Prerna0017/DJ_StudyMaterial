/* Define a class circle having data members pi and radius. Initilaize and display value of data members, calculate the area of the circle and display it.  */

class circle
{
	float pi, radius;
	
	circle (float p, float r)		//parameterized constructor
	{
		pi = p;
		radius = r;
	}
	
	void calculate()
	{
		System.out.println("Value Of Pi: " + pi);
		System.out.println("Value Of Radius: " + radius);
		float area = pi * radius * radius;
		System.out.println("Area Of the Circle: " + area);
	}
}	//end of class circle

class circlearea
{
	public static void main(String args[])
	{
		circle c1 = new circle (3.14 , 30);
		c1.calculate();
		circle c2 = new circle (3.14 , 20);
		c2.calculate();
	}
}