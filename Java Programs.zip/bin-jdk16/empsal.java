interface gross
{
	double ta = 500.00;
	double da = 1200.00;
	void gross_sal();
}	//end of parent1

class employee
{
	String name;
	float basic_sal;
	employee(String n, float b)
	{
		name = n ;
		basic_sal = b;
	}
	void display()
	{
		System.out.println("Name of the Employee: "+name);
		System.out.println("Basic Salary of the Employee: "+basic_sal);
	}
}	//end of parent2

class Salary extends employee implements gross
{
	float hra;
	Salary(String n,float b, float h)
	{
		super(n,b);
		hra = h;
	}
	void dis_sal()
	{
		display();
		System.out.println("HRA: "+hra);
	}
	public void gross_sal ()
	{
		double grossSalary = (basic_sal +da +ta + hra);	
		System.out.println("DA: "+da);
		System.out.println("TA: "+ta);
		System.out.println("Gross Salary of the Employee: "+grossSalary);
	}
}	//end of child class

class empsal
{
	public static void main(String args[])
	{
		Salary s1 = new Salary("Prerna",6000,7000);
		s1.dis_sal();
		s1.gross_sal ();
		
	}
}