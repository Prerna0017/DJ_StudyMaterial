import java.io.*;
class summod
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader br= new BufferedReader (new InputStreamReader(System.in));
		int num;
		System.out.println("Enter a number to find its sum of digits: ");
		num=Integer.parseInt(br.readLine());
		int sum=0;
		while (num>0)
		{
			sum=sum+num%10;
			num=num/10;
		}
		System.out.println("SUM: "+sum);
	}
	
}