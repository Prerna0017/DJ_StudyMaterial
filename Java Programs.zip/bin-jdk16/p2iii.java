import java.util.Scanner;
class p2iii
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter String 1: ");
		String str1 = sc.nextLine();	//string input

		System.out.println("Enter String 2: ");
		String str2 = sc.nextLine();	//string input

		int c = str1.compareTo(str2);
		if (c != 0)
		{
			System.out.println("The Strings Are Not EQUAL");
		}
		else
		{
			System.out.println("The Strings Are EQUAL");
		}
   	}
}