import java.util.*;
class v7
{
	public static void main(String args[])
	{
		Vector v = new Vector();
		String val;
		for (int i = 0; i < args.length; i++)
		{
			val = args[i];
			v.addElement(val);
		}
		System.out.println(v);
	}
}