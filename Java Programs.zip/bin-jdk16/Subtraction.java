/* Write a program to create a package Math_s having two classes as addition and subtraction. Use suitable methods in each class to perform the basic operations. */

package maths;
public class Subtraction
{
	int num1,num2;
	public void getdata(int a,int b)
	{
		num1 = a;
		num2 = b;
	}

	public void result()
	{
		int diff = num1-num2;
		System.out.println("Difference: "+diff);
	}	
}