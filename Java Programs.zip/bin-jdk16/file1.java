import java.io.*;
public class file1
{
	public static void main(String args[]) throws IOException
	{
		byte content[] = "Java Input/Output Stream Classes.".getBytes();
		ByteArrayInputStream inputStream = new ByteArrayInputStream(content);
		inputStream.read(content);
		File newFile = new File("C:/Users/Jadhav/Java/jdk-16/bin");
		FileOutputStream outputStream = new FileOutputStream(newFile);
		outputStream.write(content);
	}
}