class w5
{
	public static void main(String args[])
	{
		String str = new String ("163");
		int i = Integer.parseInt(str);
		System.out.println("Conversion of String to Integer: "+i);
	}
}