import java.io.*;
class studentclass
{
	int rollno;
	String name;
	String branch;

	studentclass(int r, String n, String b)
	{
		rollno = r;
		name = n;
		branch = b;
	}

	void display()
	{
		System.out.println("Roll No.: " + rollno);
		System.out.println("Name: " + name);
		System.out.println("Branch: "+branch);
	}
}		//end of class student

class stud
{
	public static void main (String args[]) throws IOException
	{
		DataInputStream d=new DataInputStream (System.in);
		System.out.println("Enter the Rollno. : ");
		int r1 =  Integer.parseInt(d.readLine());
		System.out.println("Enter the Name : ");
		String n1 = d.readLine();		
		System.out.println("Enter the Branch : ");
		String b1 = d.readLine();

		studentclass s1 = new studentclass (r1,n1,b1);
		s1.display();
	}
}