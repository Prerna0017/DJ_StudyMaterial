class count
{
	public static void main (String args[])
	{
		int i=1;
		do
		{
			if(i%10==0)
			{
				System.out.println(i+" ");
			}
			else
			{	
				System.out.print(i+" ");	
			}
			i++;
		}while(i<=50);	
	}
}