
interface Area
{
	public void area();
}
class circleArea implements Area
{
	double pi = 3.14;
	float rad;
	void getdata(float r)
	{
		rad = r;
	}	
	public void area()
	{
		double carea = pi*rad*rad;
		System.out.println("Area of the Circle: "+carea);
	}
}

class rectArea implements Area
{
	float l,b,h;
	void getdata(float l1, float b1, float h1)
	{
		l = l1;
		b = b1;
		h = h1;
	}	
	public void area()
	{
		double rarea = l*b*h;
		System.out.println("Area of theRectangle: "+rarea);
	}
}

class areaMain
{
	public static void main(String args[])
	{
		circleArea c = new circleArea();
		c.getdata(10f);
		c.area();

		rectArea r = new rectArea();
		r.getdata(20.3f,10.3f,3.3f);
		r.area();
	}
}