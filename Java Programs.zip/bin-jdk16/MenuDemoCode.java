import java.awt.*;
import java.awt.event.*;

class MenuDemoCode extends Frame
{
	MenuDemoCode()
	{
		MenuBar mb=new MenuBar();
		setMenuBar(mb);
		Menu m1=new Menu("Colors");
		MenuItem mn2=new MenuItem("Yellow");
		MenuItem mn3=new MenuItem("Black");
		MenuItem mn1=new MenuItem("Red");
		mn3.setEnabled(false);
		MenuItem mn4=new MenuItem("Blue");
		MenuItem mn5=new MenuItem("Green");
		m1.add(mn1);
		m1.add(mn2);
        m1.addSeparator();
		m1.add(mn3);
        m1.addSeparator();
		m1.add(mn4);
		m1.add(mn5);
		mb.add(m1);
	}
	public static void main(String args[])
	{
		MenuDemoCode m=new MenuDemoCode();
		m.setTitle("Menu Bar");
		m.setSize(500,500);
		m.setVisible(true);
		m.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent){
               System.exit(0);
            }        
         });  
	}
}