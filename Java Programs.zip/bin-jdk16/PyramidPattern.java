public class PyramidPattern  
{    
	public static void main(String args[])   
	{    
		int i;       
		for (i=1; i<=10; i+2)   
		{  
		 	System.out.println(i);	
		}   
	}   
}  