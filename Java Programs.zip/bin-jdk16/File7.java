import java.io.*;
public class File7 {

   //String filename = "text1.txt";
   public static void main(String args[]) throws IOException {
      FileUtil fileUtil = new FileUtil("text1.txt");
      System.out.println("No. of characters in file: " + fileUtil.getCharCount());
   }
}

class FileUtil {
   static BufferedReader reader = null;    
   public FileUtil(String filePath) throws FileNotFoundException {
      File file = new File(filePath);
      FileInputStream fileStream = new FileInputStream(file);
      InputStreamReader input = new InputStreamReader(fileStream);
      reader = new BufferedReader(input);
   }

   public static int getCharCount() throws IOException {
      int charCount = 0;
      String data;        
      while((data = reader.readLine()) != null) {
         charCount += data.length();                        
      }            
      return charCount;
   }
}