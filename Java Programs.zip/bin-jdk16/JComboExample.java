import javax.swing.*;
import java.awt.*;

public class JComboExample extends JFrame {
    JComboExample() {
        Container contentPane = getContentPane();
        contentPane.setLayout(new FlowLayout());
        String country[] = { "Solapur", "Pune", "Banglore", "Mumbai" };
        JComboBox cb = new JComboBox(country);
        contentPane.add(cb);
    }

    public static void main(String[] args) {
        JComboExample s = new JComboExample();
        s.setSize(400, 200);
        s.setVisible(true);
        s.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}