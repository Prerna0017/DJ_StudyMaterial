import java.util.Scanner;
class w6
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the character: ");
		char ch = sc.next().charAt(0);	//character input

		System.out.println("Is "+ch+ " a digit: "+Character.isDigit(ch) );
		System.out.println("Is "+ch+ " in Upper case: "+Character.isUpperCase(ch) );
		System.out.println("Is "+ch+ " in Lower case: "+Character.isLowerCase(ch) );
		System.out.println(ch+ " as String: "+Character.toString(ch) );
		System.out.println("Is "+ch+ " a Whitespace: "+Character.isWhitespace(ch) );
	}
}