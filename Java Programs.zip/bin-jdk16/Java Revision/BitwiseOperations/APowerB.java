package BitwiseOperations;

public class APowerB {
    public static void main(String[] args) {
        System.out.println(getAnswer(3,2));
    }

    public static int getAnswer(int base, int power){
        int ans = 1;

        while (power > 0) {
            if ((power & 1) == 1) {
                ans *= base;
            }

            base *= base;
            power = power >> 1;
        }

        return ans  ;
    }
}
