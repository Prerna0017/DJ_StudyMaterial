package BitwiseOperations;

public class MagicNo {
    public static void main(String[] args) {
        System.out.println(findMagicNo(6 ));
    }

    static int findMagicNo(int n){
        int sum = 0;
        int base = 5;
        while (n>0){
            int last = n&1;
            n>>=1;
            sum += last * base;
            base = base * 5;
        }

        return sum;
    }
}
