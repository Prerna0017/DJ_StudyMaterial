package BitwiseOperations;

public class FindUnique {
    public static void main(String[] args) {
        //if nos are repeated twicw
        // int[] arr = {2,3,4,2,6,4,3};
        // System.out.println(findUnique(arr));

        int[] arrThrice = {2,2,9,2,7,7,8,7,8,8};
        System.out.println(findUniqueThrice(arrThrice));
        //if nos are repeated thrice
    }

    public static int findUnique(int[] arr){

        int unique = 0;

        for(int n: arr){
            unique ^= n;
        }

        return unique;

    }

    public static int findUniqueThrice(int[] arr){

        int sum = 0;

        for(int n: arr){
            sum ^= n;
        }

        int unique = sum % 3;

        return unique;

    }
}
