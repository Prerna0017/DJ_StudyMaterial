package BitwiseOperations;

public class EvenOdd {
    public static void main(String[] args) {
        int n = 3909;
        if(isEven(n)){
            System.out.println("It is Even");
        }
        else{
            System.out.println("It is Odd");
        }
    }

    static boolean isEven(int n){
        return (n & 1) != 1;
    }
}
