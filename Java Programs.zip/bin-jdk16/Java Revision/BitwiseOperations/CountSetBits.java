package BitwiseOperations;

public class CountSetBits {
    public static void main(String[] args) {
        int n = 10;
        System.out.println(Integer.toBinaryString(n));

        System.out.println(count(n));
    }

    public static int count(int n){
        int count = 0;
        
        while (n>0){
            count++;
            // n -= (n & -n);   anyone of the expession can work
            n = n & n-1;
        }

        return count;
    }

}
