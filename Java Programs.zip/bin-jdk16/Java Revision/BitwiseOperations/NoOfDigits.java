package BitwiseOperations;

public class NoOfDigits {
    public static void main(String[] args) {
        int n = 10;
        int b = 2;
        System.out.println(noOfDigits(n, b));
    }

    public static int noOfDigits(int num, int base){
        return (int)(Math.log(num)/Math.log(base))+1;
    }
}
