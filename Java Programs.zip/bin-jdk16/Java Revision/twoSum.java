import java.util.Arrays;

public class twoSum {
    public static void main(String[] args) {
        
                // Scanner sc = new Scanner(System.in);
                // int[] nums = new int[4];
                // for (int i=0; i<nums.length; i++){
                //     nums[i] = sc.nextInt();
                // }
                // int target = sc.nextInt();
                // int index1 = 0;
                // int index2 = 0;
                // for (int i = 0; i<nums.length; i++){
                //     for (int j = 1; j<nums.length; j++){
                //         if (nums[i] == nums [j]){
                //             continue;
                //         }
                //         else if (nums[i]+nums[j] == target) {
                //             index1 = i;
                //             index2 = j;
                //         }   
                //     }
                // }

                // System.out.println("[" + index1 + " , " + index2 + "]");
                
                // sc.close();

        int[] nums = {3,2,4};
        int target = 7;
        System.out.println(Arrays.toString(twoSum1(nums, target)));
    }

    static int[] twoSum1(int[] nums, int target){
        int i = 0;
        while (i<nums.length){
            for(int diff = 0; diff<nums.length; diff++){
                if(diff==i){
                    continue;
                }
                if(Math.abs(nums[i]-target) == nums[diff]){
                    return new int[]{i,diff};
                }
            }
            i++;
        }
        return new int[]{-1,-1};
    }

    
}
