public class ReverseWordsInSentence {
    public static void main(String[] args) {
        System.out.println(reverseWords("Prern'a JAdhva"));
    }
    public static String reverseWords(String s) {
        String[] result = s.split(" ");
        for (int index = 0; index< result.length; index++){
            char ch;
            String str = result[index];
            result[index] = "";
            for (int i=0; i<str.length(); i++){
                ch= str.charAt(i); //extracts each character
                result[index]= ch+result[index]; //adds each character in front of the existing string
            }
        }

        StringBuffer sb = new StringBuffer();
        for(int i = 0; i < result.length; i++) {
            sb.append(result[i] + " ");
        }
        String str = sb.toString();
        
        for (String words: result){
            System.out.println(words);
        }
        
        return str;


    }
}
