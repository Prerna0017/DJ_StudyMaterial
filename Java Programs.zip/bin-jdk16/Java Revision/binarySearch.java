public class binarySearch {
    public static void main(String[] args) {
        
        int[] arr = {1,2,3,4,5,5,5,6,7,8,9,10};
        int target = 5;
        System.out.println(binSearch(arr,target));

    }

    static int binSearch(int[] arr, int target){
        int sI = 0;
        int eI = arr.length-1;
        while(sI<=eI){

            int mI = sI+(eI-sI)/2;
            
            if (target == arr[mI]){
                return mI;
            }
            else if (target > arr[mI]){
                sI = mI+1;
            }
            else if (target < arr[mI]){
                eI = mI-1;
            }

        }
        
        return -1;
    }
}
