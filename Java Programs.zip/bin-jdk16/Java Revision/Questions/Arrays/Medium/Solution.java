package Questions.Arrays.Medium;

class Solution {
    public  static boolean canJump(int[] nums) {
        if(nums.length == 1){return true;}

        int counter=0;
        boolean reachable=false;
        for (int i = 0; i< nums.length-2; i++){
            counter = nums[i] + i;
            if (counter >= nums.length-1){
                reachable =true;
            }
        }
        return reachable;
    }
    public static void main(String[] args) {
        System.out.println(canJump(new int[]{1,2,0})); 
    }
}