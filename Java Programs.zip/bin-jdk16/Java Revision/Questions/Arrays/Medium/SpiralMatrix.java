//https://leetcode.com/problems/spiral-matrix/
package Questions.Arrays.Medium;

import java.util.ArrayList;
import java.util.List;

public class SpiralMatrix {
    public static void main(String[] args) {
        int[][] matrix = new int[][]{{1,2,3},{4,5,6},{7,8,9}};
        System.out.println(spiralOrder(matrix));
    }

    public static List<Integer> spiralOrder(int[][] matrix) {
        ArrayList<Integer> list =new ArrayList<Integer>();
       int top =0, bottom = matrix.length-1, left = 0, right = matrix[0].length-1;
        while(top<=bottom && left<=right){
            for(int i = left; i<=right; i++){
                // System.out.print(matrix[top][i]+ " ");
                list.add(matrix[top][i]);
            }
            top++;
            for(int i = top; i<=bottom; i++){
                // System.out.print(matrix[i][right] + " ");
                 list.add(matrix[i][right]);
            }
            right --;
            if(top<=bottom){
                for(int i = right; i>=left; i--){
                    // System.out.print(matrix[bottom][i] + " ");
                     list.add(matrix[bottom][i]);
                }
                bottom --;
            }
            if(left<=right){
                for(int i = bottom; i>=top; i--){
                    // System.out.print(matrix[i][left] + " ");
                    list.add(matrix[i][left]);
                }
                left++;
            }
        }
        return list;
    }
}
