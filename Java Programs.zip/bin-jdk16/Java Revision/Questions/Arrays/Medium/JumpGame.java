// /https://leetcode.com/problems/jump-game/
package Questions.Arrays.Medium;

public class JumpGame {
    public static void main(String[] args) {
        System.out.println(canJump(new int[] {3,2,1,0,4}));
    }

    public static boolean canJump(int[] nums) {
        if (nums.length == 1){return true;}
        int reachable = 0;
        for (int i = 0; i<nums.length-1; i++){
            if (reachable >= nums.length-1){
                return true;
            }
            else{
                reachable += nums[i] + i; 
            }
        }
        return false;
    }
}
