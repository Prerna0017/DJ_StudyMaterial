//https://leetcode.com/problems/set-matrix-zeroes/
package Questions.Arrays.Medium;

import java.util.ArrayList;

public class SetMatrixZeroes {
    public static void main(String[] args) {
        int[][] matrix = new int[][]{{1,2,3},{4,0,6},{7,8,9}};
        setZeroes(matrix);
        for (int i = 0; i<matrix.length; i++ ){
            for (int j = 0; j<matrix[0].length; j++ ){
                System.out.print(matrix[i][j]);                    
            }
            System.out.println();
        }
    }

    public static void setZeroes(int[][] matrix) {
        ArrayList<Integer> rowsToBeZero = new ArrayList<Integer>();
        ArrayList<Integer> colsToBeZero = new ArrayList<Integer>();

        for (int i = 0; i<matrix.length; i++ ){
            for (int j = 0; j<matrix[0].length; j++ ){
                if(matrix[i][j] == 0){
                    rowsToBeZero.add(i);
                    colsToBeZero.add(j);
                }
            }
        }

        for (int i: rowsToBeZero){
            for (int col = 0; col<matrix[i].length; col++){
                matrix[i][col] = 0;
            }
        }

        for (int i: colsToBeZero){
            for (int row = 0; row<matrix.length; row++){
                matrix[row][i] = 0;
            }
        }
    }
}
