//https://leetcode.com/problems/shuffle-the-array/
package Questions.Arrays.Easy;

import java.util.Arrays;

public class ShuffleTheArray {
    public static void main(String[] args) {
        System.out.println(Arrays.toString(shuffle(new int[]{2,5,1,3,4,7}, 3)));
    }

    public static int[] shuffle(int[] nums, int n) {
        int[] ans = new int[nums.length];

        int i = 0, j = 0;
        while (i<nums.length && j<n){
            ans[i] = nums[j];
            ans[i+1] = nums[j+n];
            i+=2;
            j++;
        }


        return ans;
    }
}
