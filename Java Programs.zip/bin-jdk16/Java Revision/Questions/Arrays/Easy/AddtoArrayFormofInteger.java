//https://leetcode.com/problems/add-to-array-form-of-integer/
package Questions.Arrays.Easy;

import java.util.ArrayList;
import java.util.List;

public class AddtoArrayFormofInteger {
    public static void main(String[] args) {
        
    }

    public static List<Integer> addToArrayForm(int[] num, int k) {
        List<Integer> l = new ArrayList<>();


        return l;
    }
}
