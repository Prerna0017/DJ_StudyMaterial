//https://leetcode.com/problems/richest-customer-wealth/
package Questions.Arrays.Easy;

public class RichestCustomerWealth {
    public static void main(String[] args) {
        System.out.println(maximumWealth(new int[][]{{1,2,3},{3,2,1}}));
    }

    public static int maximumWealth(int[][] arr) {
        int maxWealth = 0;
        int temp=0;
        for (int customer=0; customer < arr.length; customer++){
            for (int account = 0; account < arr[customer].length; account++){
                temp += arr[customer][account];
            }
            
            maxWealth = Math.max(maxWealth, temp);
            temp = 0;
        }
            
        return maxWealth;
    }
}
