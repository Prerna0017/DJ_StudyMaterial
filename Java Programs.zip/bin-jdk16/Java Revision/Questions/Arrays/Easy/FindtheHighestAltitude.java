//https://leetcode.com/problems/find-the-highest-altitude/
package Questions.Arrays.Easy;

public class FindtheHighestAltitude {
    public static void main(String[] args) {
        System.out.println(largestAltitude(new int[]{44,32,-9,52,23,-50,50,33,-84,47,-14,84,36,-62,37,81,-36,-85,-39,67,-63,64,-47,95,91,-40,65,67,92,-28,97,100,81}));
    }

    public static int largestAltitude(int[] gain) {
        int[] altitudes = new int[gain.length+1];
        altitudes[0] = 0;
        int max = 0;

        for (int i =0; i<gain.length; i++){
            altitudes[i+1] = gain[i]+altitudes[i];
            if (altitudes[i+1]>max){
                max = altitudes[i+1];    
            }
        }

        return max;
    }
}
