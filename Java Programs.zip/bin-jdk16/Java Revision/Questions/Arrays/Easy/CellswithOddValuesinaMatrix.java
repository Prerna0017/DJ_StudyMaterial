//https://leetcode.com/problems/cells-with-odd-values-in-a-matrix/
package Questions.Arrays.Easy;

public class CellswithOddValuesinaMatrix {
    public static void main(String[] args) {
        System.out.println(oddCells(2, 3, new int[][]{{0,1},{1,1}}));
    }


    public static int oddCells(int m, int n, int[][] indices) {
        int count = 0;

        int[][] matrix = new int[m][n];

        for (int[] r:indices){
            //traversing the row
            for (int col=0; col<n; col++){
                matrix[r[0]][col]++;
            }

            //traversing the column
            for (int row = 0; row<m; row++){
                matrix[row][r[1]]++;
            }
        }

        for (int i = 0; i<m; i++){
            for (int j = 0; j<n; j++){
                if (matrix[i][j] % 2 != 0){
                    count++;
                }
            }
        }


        return count;
    }
}
