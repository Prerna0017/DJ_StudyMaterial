// https://leetcode.com/problems/check-if-the-sentence-is-pangram/
package Questions.Arrays.Easy;

import java.util.ArrayList;

public class CheckIftheSentenceIsPangram {
    public static void main(String[] args) {
        System.out.println(checkIfPangram(""));
    }

    // public static boolean checkIfPangram(String sentence) {
    //     boolean[] ifExists = new boolean[26];

    //     for (int i=0; i<sentence.length(); i++){
    //         char ch = sentence.charAt(i);
    //         ifExists[(int)ch-97] = true;
    //     }

    //     for (boolean bool: ifExists){
    //         if(!bool){
    //             return false;
    //         }
    //     }

    //     return true;
    // }

    public static boolean checkIfPangram(String sentence) {
        // boolean[] ifExists = new boolean[26];
        ArrayList<Character> letters = new ArrayList<>();

        for (int i=0; i<sentence.length(); i++){
            char ch = sentence.charAt(i);
            if (!letters.contains(ch)){
                letters.add(ch);
            }
        }

        if(letters.size() == 26){
            return true;
        }

        return false;
    }
}
