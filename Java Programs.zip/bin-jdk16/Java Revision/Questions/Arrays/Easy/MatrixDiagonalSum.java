//https://leetcode.com/problems/matrix-diagonal-sum/
package Questions.Arrays.Easy;

public class MatrixDiagonalSum {
    public static void main(String[] args) {
        // System.out.println(diagonalSum(new int[][]{
        //         {1,2,3},
        //         {4,5,6},
        //         {7,8,9}
        // }));

        System.out.println(diagonalSum(new int[][]{
            {1,1,1,1},
            {1,1,1,1},
            {1,1,1,1},
            {1,1,1,1}
        }));
    }

    public static int diagonalSum(int[][] mat) {
        int sum=0;

        //primary diagnol
        int r1=0,c1=0;
        while(r1<mat.length && c1<mat.length){
            sum += mat[r1][c1];
            r1+=1;
            c1+=1;
        }

        //secondary diagnol
        int r2=0,c2=mat.length-1;
        while(r2<=mat.length && c2>=0){
            sum += mat[r2][c2];
            r2+=1;
            c2-=1;
        }

        if (mat.length % 2 != 0){
            int mid = (int)mat.length/2;
            sum = sum - mat[mid][mid];
        }

        return sum;
    }
}
