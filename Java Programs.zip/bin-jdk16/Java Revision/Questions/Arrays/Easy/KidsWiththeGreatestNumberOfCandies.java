//https://leetcode.com/problems/kids-with-the-greatest-number-of-candies/
package Questions.Arrays.Easy;

import java.util.ArrayList;
import java.util.List;

public class KidsWiththeGreatestNumberOfCandies {
    public static void main(String[] args) {
        System.out.println(kidsWithCandies(new int[]{12,1,12}, 10));
    }

    public static List<Boolean> kidsWithCandies(int[] candies, int extraCandies) {
        List<Boolean> result = new ArrayList<Boolean>();
        for (int i = 0; i < candies.length; i++){
            candies[i] += extraCandies;
            boolean isMax = max(candies,candies[i]);
            candies[i] -= extraCandies;
            result.add(isMax);
        }
        return result;
    }

    private static boolean max(int[] candies, int maxCandies) {
        int max = maxCandies;
        for (int i = 0; i<candies.length; i++){
            if (candies[i] > maxCandies){
                max = candies[i];
            }
        }

        if(max == maxCandies){
            return true;
        }
        return false;
    }
}
