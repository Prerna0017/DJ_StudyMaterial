//package -> is used to group related classes (For eg: folder in a file directory)
class intro {   //file and class name is the same
    public static void main(String args[]){     //default function to execute first, entry point into the application
        //public-> making it accessible to all other classes
        //static-> without making obj, running the program. Declares this method as one that belongs to the entire class and not a part of any objects of the class. The main must always be declared as static since the interpreter uses this method before any objects are created. It allows main() to be called without having to instantiate a particular instance of the class. This is necessary since main() is called by the JVM before any objects are made.
        
        String msg = "Hello World";
        System.out.println(msg);

        //byte -> takes 1 byte = 8bits (-128 to 127), default-0
        byte age = 34;
        System.out.println(age);

        //short -> takes 2 byte = 16bit (-32,768 to +32,767), default-0
        short s = 7899;
        System.out.println(s);

        //int -> takes 4, default - 0
        int a =90;
        System.out.println(a);

        //float -> take 4, default-0.0f
        float pi = 3.14f;
        System.out.println(pi);

        //long -> take 8, default-0
        long l = 899999999999999999L;
        System.out.println(l);

        //double -> take 8, default-0.0d
        double ans = 90.3456d;
        System.out.println(ans);

        //char -> takes 2 byte = 16bits (0 to 65535[2^16 - 1]) bcoz supports unicode (default - '\u0000')
        char ch = 'a';
        System.out.println(ch);

        //boolean -> takes 1bit, depends on JVM (default - false)
        boolean condition = true;
        System.out.println(condition);

        String name = "Prerna";
        System.out.println(name);
    }
} 

/*
Naming conventions:
    -> for classes: PascalConvention (MainClass)
    -> for functions: camelCaseConvention (mainFunction)
*/