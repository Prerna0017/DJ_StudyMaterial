import java.util.Scanner;

public class input {
    public static void main(String args[]) {
        
        System.out.println("Input with Scanner");

        Scanner sc = new Scanner(System.in);
        //System.in -> take the keyboard input

        System.out.println("Enter your Name: ");
        String name = sc.nextLine();    //gives full line and next() gives just the first word

        System.out.println("Your name is "+name);

        System.out.println("Enter your Salary: ");
        float sal = sc.nextFloat();

        System.out.println("Your salary is "+sal);

        boolean b = sc.hasNextInt();    //if input is int
        System.out.println(b);

        sc.close();
    }
}
