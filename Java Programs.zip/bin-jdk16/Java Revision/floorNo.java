public class floorNo {
    public static void main(String[] args) {
        int[] arr = {1,5,6,70,72,77,110};
        int target = 22;
        System.out.println(floor(arr,target));
    }

    static int floor(int[] arr, int target){

        int sI = 0;
        int eI = arr.length-1;
        int mI=0;

        while(sI<=eI){

            mI = sI+(eI-sI)/2;
            
            if (target == arr[mI]){
                return target;
            }
            else if (target > arr[mI]){
                sI = mI+1;
            }
            else if (target < arr[mI]){
                eI = mI-1;
            }
            
        }
        
        return arr[eI];

    }
}
