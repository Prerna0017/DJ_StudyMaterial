import java.util.Arrays;

public class cyclicSort {
    public static void main(String[] args) {
        int[] arr = {3,5,2,1,4,7,6,9,8};
        sort(arr);
        System.out.println(Arrays.toString(arr));
    }

    static void swap(int[] arr, int index1, int index2){
        int temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

    static void sort(int[] arr){
        // for (int i=0; i<arr.length; i++){
        //     if (arr[i] != i+1){
        //         swap (arr, i, arr[i]-1);
        //     }
        // }

        int i = 0;
        while(i<arr.length){
            if (arr[i] != i+1){
                swap (arr, i, arr[i]-1);
            }
            else{
                i++;
            }
        }
    }
}

