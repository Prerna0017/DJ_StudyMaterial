import java.util.Arrays;

public class setMismatch {
    public static void main(String[] args) {
        int[] arr = {1,3,3,4};

        System.out.println(Arrays.toString(findErrorNums(arr)));
    }

    public static void swap(int[] arr, int index1, int index2){
        int temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

    public static int[] findErrorNums (int[] arr) {
        int[] solution = new int[2];      
        int i = 0;
        while(i<arr.length){
            if (arr[i] != i+1){
                if (arr[i] == arr[arr[i]-1]){
                    i++;
                }
                else{
                    swap (arr, i, arr[i]-1);
                }
            }
            else{
                i++;
            }
        }
        for(int index = 0; index<=arr.length-1; index++){
            if (arr[index] != index+1){
                solution[0] = arr[index];
                solution[1] = index+1;
            }
        }

        return solution;
    }
}
