import java.util.ArrayList;
import java.util.Arrays;

public class duplicateNo {
    public static void main(String[] args) {
        int[] arr = {4,3,2,7,8,2,3,1};
        // System.out.println(findDuplicate(arr));
        
        System.out.println(findAllDuplicate(arr));
        System.out.println(Arrays.toString(arr));
    }
    public static void swap(int[] arr, int index1, int index2){
        int temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }
    static int findDuplicate(int[] arr){
        int i = 0;
        while(i<arr.length){
            if (arr[i] < arr.length && arr[i] != arr[arr[i]] ){
                swap (arr, i, arr[i]);
            }
            else{
                return arr[i];
            }
        }
        return arr[0];
        
    }

    static ArrayList<Integer> findAllDuplicate(int[] arr){
    // static void findAllDuplicate(int[] arr){
        ArrayList <Integer> duplicates = new ArrayList<>();
        int i = 0;
        while (i < arr.length) {
            int correct = arr[i] - 1;
            if (arr[i] != arr[correct]) {
                swap(arr, i , correct);
            } else {
                i++;
            }
        }
        for (int index = 0; index <= arr.length-1; index++){
            if (arr[index] != index+1){
                duplicates.add(arr[index]);
            }
        }
        return duplicates;
        
    }
    
}
