

public class stringSearch {
    public static void main(String[] args) {
        String name = "Prerna";
        char toFind = 'P';

        System.out.println(search(name, toFind));
    }

    static boolean search(String name, char toFind) {
        
        if (name.length() == 0){
            return false;
        }

        // for (int i = 0; i<name.length(); i++){
        //     if (toFind == name.charAt(i)){
        //         return true;
        //     }
        // }

            for (char ch: name.toCharArray()){
                if (toFind == ch){
                    return true;
                }
            }

        return false;
    }

    
}
