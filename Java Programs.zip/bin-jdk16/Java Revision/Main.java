import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

class Result {

    /*
     * Complete the 'divisibleSumPairs' function below.
     *
     * The function is expected to return an INTEGER.
     * The function accepts following parameters:
     *  1. INTEGER n
     *  2. INTEGER k
     *  3. INTEGER_ARRAY ar
     */

    public static int divisibleSumPairs(int n, int k, List<Integer> ar) {
    // Write your code here
        ArrayList<ArrayList<Integer>> list = new ArrayList<ArrayList<Integer>>();

        for (int i = 0; i<n; i++){
            for (int j = i+1; j<n; j++){
                int sum = ar.get(i)+ar.get(j);
                if (sum % k == 0){
                    ArrayList<Integer> l = new ArrayList<Integer>();
                    l.add(i);
                    l.add(j);
                    list.add(l);
                }
            }
        }

        // System.out.println(list);

        return list.size();
    }

}

public class Main {
    public static void main(String[] args) throws IOException {
        List<Integer> list = Arrays.asList(1,2,3,4,5,6);

        int result = Result.divisibleSumPairs(6, 5, list);
            System.out.println(result);

    }
}
