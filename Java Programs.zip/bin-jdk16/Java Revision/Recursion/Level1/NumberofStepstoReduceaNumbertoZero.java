package Recursion.Level1;

public class NumberofStepstoReduceaNumbertoZero {
    public static void main(String[] args) {
        System.out.println(noOfSteps(8));
    }

    static int noOfSteps(int n){
        return helper(n, 0);
    }

    public static int helper(int n,int c){
        if(n == 0){
            return c;
        }
        if (n%2 == 0) {
            return helper(n/2, ++c);
        }
        else{
            return helper(n-1, ++c);
        }
        
    }
}
