package Recursion.Level1;

public class Print1toN {
    public static void main(String[] args) {
        // print1toN(5);
        funBoth(5);
    }


    public static void print1toN(int n){
        if(n<1){
            return;
        }   
        print1toN(n-1);
        System.out.println(n);
    } 


    static void funBoth(int n) {
        if (n == 0) {
            return;
        }
        System.out.println(n);
        funBoth(n-1);
        System.out.println(n);
    }
}
