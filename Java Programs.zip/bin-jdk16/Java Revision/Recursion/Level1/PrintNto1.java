package Recursion.Level1;

public class PrintNto1 {
    public static void main(String[] args) {
        printN(5);
    }

    public static void printN(int n){
        System.out.println(n);
        if(n>1){
            printN(n-1);
        }      
        
        // if(n==0){
        //     return;
        // }
    } 
}
