package Recursion.Maze;

import java.util.ArrayList;

public class MazeAllDirection {
    public static void main(String[] args) {
        boolean[][] maze = {
            {true, true, true},
            {true, true, true},
            {true, true, true}
        };
        System.out.println(printPathAllDirections("", maze, 0,0));
    }

    /*this recursion is never ending because after a level we again go back to 0,0 hence making the recursion never ending
    To solve ths problem , we need to avoid revisiting the cells that are already being traversed

    We can mark the visited cells to boolean false in the maze.
    So that we wont go there

    */

    static ArrayList<String> printPathAllDirections(String p, boolean[][] maze, int r, int c){
        if (r == maze.length-1 && c == maze[0].length-1){
            ArrayList<String> list = new ArrayList<>();
            list.add(p);
            return list;
        }

        if(!maze[r][c]){
            return new ArrayList<>();
        }

        maze[r][c] = false;     //Change made for that particular path

        ArrayList<String> ans = new ArrayList<>();

        if (r>0){
            ans.addAll(printPathAllDirections(p+'U', maze, r-1, c));
        }
        if (r<maze.length-1){
            ans.addAll(printPathAllDirections(p+'D', maze, r+1, c));
        }
        if (c<maze[0].length-1){
            ans.addAll(printPathAllDirections(p+'R', maze, r, c+1));
        }
        if (c>0){
            ans.addAll(printPathAllDirections(p+'L', maze, r, c-1));
        }
        if (r<maze.length-1 && c<maze[0].length-1){
            ans.addAll(printPathAllDirections(p+'d', maze, r+1, c+1));
        }

        //this is the line where the function will be over 
        //befor ethe function gets removed also remove the changes that were made by that function

        maze[r][c] = true;      //This is BACKTRACKING

        return ans;
    }

}
