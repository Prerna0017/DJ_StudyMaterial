package Recursion.Maze;

import java.util.ArrayList;

public class Maze1 {
    public static void main(String[] args) {
        System.out.println(printPathDiagonalList("", 3, 3));
        
    }

    static int countPath (int r, int c){
        if (r==1 || c==1){
            return 1;
        }
        int count = 0;

        count += countPath(r-1, c);
        count += countPath(r, c-1);

        return count;
    }

    static void printPath(String p, int r, int c){
        if (r == 1 && c == 1){
            System.out.println(p);
            return;
        }

        if (r>1){
            printPath(p+'D', r-1, c);
        }
        if (c>1){
            printPath(p+'R', r, c-1);
        }
    }

    static void printPathDiagonal(String p, int r, int c){
        if (r == 1 && c == 1){
            System.out.println(p);
            return;
        }

        if (r>1){
            printPathDiagonal(p+'D', r-1, c);
        }
        if (c>1){
            printPathDiagonal(p+'R', r, c-1);
        }
        if (r>1 && c>1){
            printPathDiagonal(p+'d', r-1, c-1);
        }
    }

    static ArrayList<String> printPathList(String p, int r, int c){
        if (r == 1 && c == 1){
            ArrayList<String> list = new ArrayList<>();
            list.add(p);
            return list;
        }
        ArrayList<String> ans = new ArrayList<>();
        if (r>1){
            ans.addAll(printPathList(p+'D', r-1, c));
        }
        if (c>1){
            ans.addAll(printPathList(p+'R', r, c-1));
        }

        return ans;
    }

    static ArrayList<String> printPathDiagonalList(String p, int r, int c){
        if (r == 1 && c == 1){
            ArrayList<String> list = new ArrayList<>();
            list.add(p);
            return list;
        }

        ArrayList<String> ans = new ArrayList<>();

        if (r>1){
            ans.addAll(printPathDiagonalList(p+'D', r-1, c));
        }
        if (c>1){
            ans.addAll(printPathDiagonalList(p+'R', r, c-1));
        }
        if (r>1 && c>1){
            ans.addAll(printPathDiagonalList(p+'d', r-1, c-1));
        }

        return ans;
    }
}


