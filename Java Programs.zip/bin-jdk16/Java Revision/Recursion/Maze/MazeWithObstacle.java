package Recursion.Maze;

import java.util.ArrayList;

public class MazeWithObstacle {
    public static void main(String[] args) {
        boolean[][] maze = {
            {true, true, true},
            {true, false, true},
            {true, true, true}
        };
        System.out.println(printPathObstacleList("", maze, 0,0));
    }

    static ArrayList<String> printPathObstacleList(String p, boolean[][] maze, int r, int c){
        if (r == maze.length-1 && c == maze[0].length-1){
            ArrayList<String> list = new ArrayList<>();
            list.add(p);
            return list;
        }

        if(!maze[r][c]){
            return new ArrayList<>();
        }

        ArrayList<String> ans = new ArrayList<>();

        if (r<maze.length-1){
            ans.addAll(printPathObstacleList(p+'D', maze, r+1, c));
        }
        if (c<maze[0].length-1){
            ans.addAll(printPathObstacleList(p+'R', maze, r, c+1));
        }
        if (r<maze.length-1 && c<maze[0].length-1){
            ans.addAll(printPathObstacleList(p+'d', maze, r+1, c+1));
        }

        return ans;
    }
}
