package Recursion;

import java.util.Arrays;

public class BubbleSort {
    public static void main(String[] args) {
        int[] arr = {9,8,7,6,5};
        // System.out.println(Arrays.toString(sort(arr,0)));
        bubble(arr,arr.length-1,0);
        System.out.println(Arrays.toString(arr));
    }

    public static void bubble(int[] arr, int r, int c) {
        if (r==0){return;}
        if (c<r){
            if (arr[c] > arr[c+1]){
                swap(arr, c, c+1);
            }
            bubble(arr, r, c+1);
        }
        else{
            bubble(arr, r-1, 0);
        }
    }
    
    public static int[] sort (int[] arr,int i){
        
        if (i==arr.length-1){
            return sort(arr, i=0);
        }

        if (arr[i] > arr[i+1]){
            swap (arr, i, i+1);
            return sort(arr, i+1);
        }
        if (arr[i] < arr[i+1]){
            if(i==0){
                return arr;
            }
            return sort(arr, i=0);
        }
        return arr;
    }

    static void swap(int[] arr, int index1, int index2){
        int temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

    
}
