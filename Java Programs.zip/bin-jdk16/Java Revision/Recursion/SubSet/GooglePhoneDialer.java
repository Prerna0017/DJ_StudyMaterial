package Recursion.SubSet;

import java.util.ArrayList;
import java.util.List;

public class GooglePhoneDialer {
    public static void main(String[] args) {
        System.out.println(getCombinationsList("", "23"));
    }

    static void getCombinations(String p, String up){
        if (up.isEmpty()){
            System.out.println(p);
            return;
        }

        int digit = up.charAt(0) - '0'; //this will conert '2' into 2;

        for (int i = (digit-1)*3; i<(digit*3); i++){
            char ch = (char)('a'+i);
            getCombinations(p+ch, up.substring(1));
        }
    }

    static List<String> getCombinationsList(String p, String up){
        if (up.isEmpty()){
            ArrayList<String> list = new ArrayList<>();  
            list.add(p);
            return list;
        }

        int digit = up.charAt(0) - '0'; //this will conert '2' into 2;
        ArrayList<String> ans = new ArrayList<>();

        for (int i = (digit-1)*3; i<(digit*3); i++){
            char ch = (char)('a'+i);
            ans.addAll(getCombinationsList(p+ch, up.substring(1)));
        }
        return ans;
    }

    public static List<String> getCombinationsListCorrect(String ans, String ip){
        if(ip.isEmpty()) {
           ArrayList<String> list = new ArrayList<>();
           list.add(ans);
           return list;
       }
       
       int digit = ip.charAt(0) - '0';
       int i=(digit-2)*3;
       if(digit > 7) {
           i+=1;
       }
       int len = i+3;
       if(digit == 7 || digit == 9) {
           len+=1;
       }
       
       ArrayList<String> list = new ArrayList<>();
               
       for(; i<len; i++) {
           char ch = (char)('a' + i);
           list.addAll(getCombinationsListCorrect(ans+ch, ip.substring(1)));
       }
       
       return list;
   }
}
