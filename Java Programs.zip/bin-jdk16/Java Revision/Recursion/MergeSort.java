package Recursion;

import java.util.Arrays;

public class MergeSort {
    public static void main(String[] args) {
        int[] arr = {8,3,4,12,5,435,908,78,11,89,78,55,456,222,124,23};
        
        System.out.println(Arrays.toString(sort(arr)));
    }

    

    private static int[] sort(int[] arr) {
        if (arr.length == 1){
            return arr;
        }
        int mid = arr.length / 2;
        int[] left =  sort(Arrays.copyOfRange(arr, 0, mid));
        int[] right =  sort(Arrays.copyOfRange(arr, mid, arr.length));

        return merge(left, right);
    }

    private static int[] merge(int[] left, int[] right) {
        int[] mix = new int [left.length + right.length];
        int pointer1 = 0, pointer2 = 0;
        int index=0;
        while (pointer1 < left.length && pointer2 < right.length){
            if (left[pointer1] < right[pointer2]){
                mix[index] = left[pointer1];
                pointer1+=1;
            }
            else{
                mix[index] = right[pointer2];
                pointer2+=1;
            }
            index+=1;
        }

        if(pointer1 < left.length){
            for(int i = pointer1; i < left.length; i++){
                mix[index] = left[pointer1];
                index+=1;
                pointer1+=1;
            }
        }
        if(pointer2 < right.length){
            for(int i = pointer2; i < right.length; i++){
                mix[index] = right[pointer2];
                index+=1;
                pointer2+=1;
            }
        }
        return mix;
    }
}
