package Recursion.String;

public class SkipAString {
    public static void main(String[] args) {
        // System.out.println(skip("applejhdbapplenfhapple"));
        System.out.println(skipAppNotApple("applejhdbappn"));
    }

    static String skip(String original){
        if (original.isEmpty()){
            return "";
        }

        if (original.startsWith("apple")){
            return skip(original.substring(5));
        }
        else{
            return original.charAt(0) + skip(original.substring(1));
        }
    }

    static String skipAppNotApple(String original){
        if (original.isEmpty()){
            return "";
        }

        if (original.startsWith("app") && !original.startsWith("apple")){
            return skip(original.substring(3));
        }
        else{
            return original.charAt(0) + skip(original.substring(1));
        }
    }
}
