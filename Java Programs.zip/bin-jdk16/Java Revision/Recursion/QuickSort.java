package Recursion;

import java.util.Arrays;

public class QuickSort {
    public static void main(String[] args) {
        int[] arr = {5,4,3,2,1};
        // sort(arr, 0, arr.length-1);
        // System.out.println(Arrays.toString(arr));

        Arrays.sort(arr);
    }

    public static void sort(int[] arr, int low, int hi) {
        if (low >= hi){
            return;
        }

        int s = low;
        int e = hi;
        int mid = s + (e-s)/2;
        int pivot = arr[mid];

        while (s <= e){
            while (arr[s] < pivot){
                s++;
            }

            while (arr[e] > pivot){
                e--;
            }

            if(s <= e){
                swap (arr,s,e);
                s++;
                e--;
            }
        }

        sort(arr, low, e);
        sort(arr, s, hi);
    }

    static void swap(int[] arr, int index1, int index2){
        int temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }
}
