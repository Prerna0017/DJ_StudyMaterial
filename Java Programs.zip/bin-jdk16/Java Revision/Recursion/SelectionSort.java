package Recursion;

import java.util.Arrays;

public class SelectionSort {
    public static void main(String[] args) {
        int[] arr = {4,3,23,45,88,67,88,9,1};
        // System.out.println(Arrays.toString(sort(arr, arr.length-1)));
        selection(arr, arr.length, 0, 0);
        System.out.println(Arrays.toString(arr));
    }

    static void selection(int[] arr, int r, int c, int max) {
        if (r == 0) {
            return;
        }
        if (c < r) {
            if (arr[c] > arr[max]) {
                selection(arr, r, c+1, c);
            } else {
                selection(arr, r, c+1, max);
            }
        } else {
            int temp = arr[max];
            arr[max] = arr[r-1];
            arr[r-1] = temp;
            selection(arr, r-1, 0, 0);
        }
    }

    public static int[] sort(int[] arr, int e) {
        
        if (e == 0){
            return arr;
        }
        int index = findMaxIndex(arr, 0 ,e);
        swap(arr, index, e);

        return sort(arr, e-1);
    }

    static void swap(int[] arr, int index1, int index2){
        int temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

    public static int findMaxIndex(int[] arr, int sI, int eI) {
        int maxIndex = 0;
        for(int i = sI; i<=eI; i++){
            if (arr[maxIndex] < arr[i]){
                maxIndex = i;
            }
        }
        return maxIndex;
    }
}
