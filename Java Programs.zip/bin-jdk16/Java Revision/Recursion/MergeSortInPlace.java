package Recursion;

import java.util.Arrays;

public class MergeSortInPlace {
    public static void main(String[] args) {
        int[] arr = {8,3,4,12,5,435,908,78,11,89,78,55,456,222,124,23};
        sort(arr,0,arr.length);
        System.out.println(Arrays.toString(arr));
    }

    

    private static void sort(int[] arr, int s, int e) {
        if (e-s == 1){
            return;
        }
        int mid = s + (e-s)/ 2;
        sort(arr, s, mid);
        sort(arr, mid, e);

        merge(arr, s, mid, e);
    }

    private static void merge(int[] arr, int s, int m, int e) {
        int[] mix = new int [e-s];
        int pointer1 = s, pointer2 = m;
        int index=0;
        while (pointer1 < m && pointer2 < e){
            if (arr[pointer1] < arr[pointer2]){
                mix[index] = arr[pointer1];
                pointer1+=1;
            }
            else{
                mix[index] = arr[pointer2];
                pointer2+=1;
            }
            index+=1;
        }

        while (pointer1<m){
            mix[index] = arr[pointer1];
            pointer1++;
            index++;
        }

        while (pointer2<e){
            mix[index] = arr[pointer2];
            pointer2++;
            index++;
        }

        System.arraycopy(mix, 0, arr, s+0, mix.length);
    }
}
