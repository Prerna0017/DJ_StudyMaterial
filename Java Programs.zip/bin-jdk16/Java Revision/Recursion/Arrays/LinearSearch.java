package Recursion.Arrays;

public class LinearSearch {
    public static void main(String[] args) {
        int[] arr = new int[]{12,23,1,1,23,2};
        System.out.println(linearSearch1(arr,2, 0));
        System.out.println(linearSearchFromLast(arr,1, arr.length-1));
        System.out.println(linearSearch2(arr,2, 0));
        System.out.println(linearSearch3(arr,2, arr.length-1));
    }

    public static int linearSearch1(int[] arr, int target, int i){
        if(arr[i] == target){
            return i;
        }
        if (i == arr.length-1){
            return -1;
        }
        return linearSearch1(arr, target, i+1);
    }

    public static int linearSearchFromLast(int[] arr, int target, int i){
        if(arr[i] == target){
            return i;
        }
        if (i == -1){
            return -1;
        }
        return linearSearchFromLast(arr, target, i-1);
    }

    public static boolean linearSearch2(int[] arr, int target, int i){
        if (i == arr.length){
            return false;
        }
        return arr[i]==target || linearSearch2(arr, target, i+1);
    }

    public static boolean linearSearch3(int[] arr, int target, int i){
        if (i == -1){
            return false;
        }
        return arr[i]==target || linearSearch3(arr, target, i-1);
    }
}
