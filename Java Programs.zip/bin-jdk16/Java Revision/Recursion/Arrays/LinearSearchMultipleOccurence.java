package Recursion.Arrays;

import java.util.ArrayList;

public class LinearSearchMultipleOccurence{
    public static void main(String[] args) {
        int[] arr = {40,122,40,40,40,89,40};
        System.out.println(search(arr,40,0, new ArrayList<Integer>(10)));
        System.out.println(search2(arr,40,0));
    }

    private static ArrayList<Integer> search(int[] arr, int target, int i, ArrayList<Integer> occurences) {
        if(arr[i] == target){
            occurences.add(i);
        }
        if (i == arr.length-1){
            return occurences;
        }
        return search(arr, target, i+1, occurences);
    }


//dont use the below approach bcoz its not optimized as we are creating new ArrayList evertime
    private static ArrayList<Integer> search2(int[] arr, int target, int i) {
        ArrayList<Integer> occurences = new ArrayList<Integer>(10);
        if(arr[i] == target){
            occurences.add(i);
        }
        if (i == arr.length-1){
            return occurences;
        }

        ArrayList<Integer> answerFromBelow = search2(arr, target, i+1);
        occurences.addAll(answerFromBelow);
        return occurences;
    }
}