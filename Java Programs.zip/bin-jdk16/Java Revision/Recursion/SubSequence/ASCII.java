package Recursion.SubSequence;

import java.util.ArrayList;

public class ASCII {
    public static void main(String[] args) {
        // char c = 's';
        // System.out.println((int)(c));
        findSequenceASCII("", "abc");
        System.out.println(findSubSeqASCIIArrayList("", "anc"));
    }

    private static void findSequenceASCII(String p, String up) {
        if (up.isEmpty()){  
            if(p.isEmpty()){
                return;
            }
            System.out.print(p + "\t");
            return;
        }

        char ch = up.charAt(0);
        findSequenceASCII(p+ch, up.substring(1));
        findSequenceASCII(p, up.substring(1));
        findSequenceASCII(p + (ch+0), up.substring(1));
        
    }

    public static ArrayList<String> findSubSeqASCIIArrayList(String p, String up) {
        if (up.isEmpty()){
            ArrayList<String> list = new ArrayList<>();  
            list.add(p);
            return list;
        }

        char ch = up.charAt(0);
        ArrayList<String> first = findSubSeqASCIIArrayList(p+ch, up.substring(1));
        ArrayList<String> second = findSubSeqASCIIArrayList(p, up.substring(1));
        ArrayList<String> third = findSubSeqASCIIArrayList(p + (ch+0), up.substring(1));

        first.addAll(second);
        first.addAll(third);
        return first;
        
    }
}
