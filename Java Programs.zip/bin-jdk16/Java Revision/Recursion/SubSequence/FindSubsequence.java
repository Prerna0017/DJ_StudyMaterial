package Recursion.SubSequence;

import java.util.ArrayList;

public class FindSubsequence {
    public static void main(String[] args) {
        System.out.println(findInSequence("","rjufvjafbxnbgriwgokdgqdqewn","mjmqqjrmzkvhxlyruonekhhofpzzslupzojfuoztvzmmqvmlhgqxehojfowtrinbatjujaxekbcydldglkbxsqbbnrkhfdnpfbuaktupfftiljwpgglkjqunvithzlzpgikixqeuimmtbiskemplcvljqgvlzvnqxgedxqnznddkiujwhdefziydtquoudzxstpjjitmiimbjfgfjikkjycwgnpdxpeppsturjwkgnifinccvqzwlbmgpdaodzptyrjjkbqmgdrftfbwgimsmjpknuqtijrsnwvtytqqvookinzmkkkrkgwafohflvuedssukjgipgmypakhlckvizmqvycvbxhlljzejcaijqnfgobuhuiahtmxfzoplmmjfxtggwwxliplntkfuxjcnzcqsaagahbbneugiocexcfpszzomumfqpaiydssmihdoewahoswhlnpctjmkyufsvjlrflfiktndubnymenlmpyrhjxfdcq"));
        findSequence("", "anc");
        System.out.println(isSubsequence("rjufvjafbxnbgriwgokdgqdqewn","mjmqqjrmzkvhxlyruonekhhofpzzslupzojfuoztvzmmqvmlhgqxehojfowtrinbatjujaxekbcydldglkbxsqbbnrkhfdnpfbuaktupfftiljwpgglkjqunvithzlzpgikixqeuimmtbiskemplcvljqgvlzvnqxgedxqnznddkiujwhdefziydtquoudzxstpjjitmiimbjfgfjikkjycwgnpdxpeppsturjwkgnifinccvqzwlbmgpdaodzptyrjjkbqmgdrftfbwgimsmjpknuqtijrsnwvtytqqvookinzmkkkrkgwafohflvuedssukjgipgmypakhlckvizmqvycvbxhlljzejcaijqnfgobuhuiahtmxfzoplmmjfxtggwwxliplntkfuxjcnzcqsaagahbbneugiocexcfpszzomumfqpaiydssmihdoewahoswhlnpctjmkyufsvjlrflfiktndubnymenlmpyrhjxfdcq"));
    }


    private static boolean isSubsequence(String s, String t) {
        ArrayList<String> subSequences = findSubSeqArrayList("",t);
        if (subSequences.contains(s)){
            return true;
        }
        return false;
    }


    private static void findSequence(String p, String up) {
        if (up.isEmpty()){  
            if (p.isEmpty()){
                return;
            }
            System.out.println(p);
            return;
        }

        char ch = up.charAt(0);
        findSequence(p+ch, up.substring(1));
        findSequence(p, up.substring(1));
        
    }

    public static ArrayList<String> findSubSeqArrayList(String p, String up) {
        if (up.isEmpty()){
            ArrayList<String> list = new ArrayList<>();  
            list.add(p);
            return list;
        }

        char ch = up.charAt(0);
        ArrayList<String> left = findSubSeqArrayList(p+ch, up.substring(1));
        ArrayList<String> right = findSubSeqArrayList(p, up.substring(1));

        left.addAll(right);
        return left;
        
    }

    private static boolean findInSequence(String p, String up, String target) {
        if (up.isEmpty()){  
            if (p.equals(target)){
                return true;
            }
            System.out.println(p);
            return false;
        }

        char ch = up.charAt(0);
        boolean left = findInSequence(p+ch, up.substring(1),target);
        boolean right = findInSequence(p, up.substring(1),target);
        return left || right;
        
        
    }
}
