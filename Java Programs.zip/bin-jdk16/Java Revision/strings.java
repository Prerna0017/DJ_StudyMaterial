public class strings {
    public static void main(String[] args) {
        String a = "Prerna Jadhav";
        String b = "Prerna Jadhav";
        String c = a;

        System.out.println(a == b);
        System.out.println(a == c);

        String name1 = new String ("Prerna");
        String name2 = new String ("Prerna");

        System.out.println(name1 == name2);
        System.out.println(name1 == name2);

        System.out.println("a"+'b');
    }
}
