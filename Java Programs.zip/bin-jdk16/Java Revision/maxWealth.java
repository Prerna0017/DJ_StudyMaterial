import java.util.ArrayList;

public class maxWealth {
    public static void main(String[] args) {
        int[][] accounts = {
            {1,2,3},
            {3,2,20},
            {34}
        };

        System.out.println(findMaxWealth(accounts));
    }

    static int findMaxWealth(int[][] arr){
        ArrayList<Integer> individualTotalWealth = new ArrayList<>();
        int maxWealth = 0;
        for (int customer=0; customer < arr.length; customer++){
            for (int account = 0; account < arr[customer].length; account++){
                maxWealth += arr[customer][account];
                individualTotalWealth.add(maxWealth);
            }
            maxWealth = 0;
        }
        
        int maximum = 0;
        for (int i = 1; i < individualTotalWealth.size(); i++) {
            if (maximum < individualTotalWealth.get(i))
                maximum = individualTotalWealth.get(i);
        }
        
        return maximum;
    }
}
