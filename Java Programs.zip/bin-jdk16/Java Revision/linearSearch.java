public class linearSearch {
    public static void main(String[] args) {
        
        int[] arr = {12,11,234,56,7,80,9,99};
        int target = 99;
        System.out.println(linearSearchFunc(arr, target));
        System.out.println(linearSearchInRange(arr, target,4, 7));

    }

    //search in array
    static int linearSearchFunc(int[] arr, int target){
        if (arr.length == 0){
            return -1;
        }
        
        for (int index=0; index<arr.length; index++){
            if (arr[index] == target){
                return index;
            }
        }

        return -1;
        
    }

    static int linearSearchInRange(int[] arr, int target, int start, int end){
        if (arr.length == 0){
            return -1;
        }
        
        for (int index=start; index <= end; index++){
            if (arr[index] == target){
                return index;
            }
        }

        return -1;
        
    }
}
