public class max {
    public static void main(String[] args) {
        int[] arr = {1,21,300,4,1,9,9000};

        // System.out.println(MaxNum(arr));
        // System.out.println(MaxNumBtnIndex(arr,4,5));
        System.out.println(findMaxIndex(arr,0,5));

    }

    public static int findMaxIndex(int[] arr, int sI, int eI) {
        int maxIndex = 0;
        for(int i = sI; i<=eI; i++){
            if (arr[maxIndex] < arr[i]){
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    public static int MaxNum(int[] arr) {
        int max = 0;

        for (int i = 0; i<arr.length; i++){
            if(i==arr.length-1){
                max = (max < arr[arr.length-1]) ? arr[arr.length-1] : max;
                break;
            }
            if (arr[i] > arr[i+1] || arr[i] == arr[i+1]){
                max = arr[i];
            }
        }

        return max;
    }

    public static int MaxNumBtnIndex(int[] arr, int sI, int eI) {
        int max = 0;

        for (int i = sI; i<eI; i++){
            if(i==eI-1){
                max = (max < arr[eI]) ? arr[eI] : max;
                break;
            }
            if (arr[i] > arr[i+1] || arr[i] == arr[i+1]){
                max = arr[i];
            }
        }

        return max;
    }

}
