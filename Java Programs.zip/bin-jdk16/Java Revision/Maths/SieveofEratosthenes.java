package Maths;


public class SieveofEratosthenes {
    public static void main(String[] args) {
        int n = 11;
        boolean[] prime = new boolean[n+1];
        listPrimeNo(n,prime);
        for (int i=0 ; i < prime.length; i++){
            if(!prime[i]){
                System.out.println(i);
            }
        }
    }

    private static void listPrimeNo(int n, boolean[] prime) {
        prime[0] = true;
        prime[1] = true;
        for (int i = 2; i*i <= n+1; i++){
            if(!prime[i]){
                for (int j = 2*i; j <= n; j+=i){
                    prime[j] = true;
                }
            }
        }
    }
}
