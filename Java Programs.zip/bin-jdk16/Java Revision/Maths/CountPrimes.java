package Maths;


public class CountPrimes {
    public static void main(String[] args) {
        int n = 11;
        System.out.println(countPrimes(n));
       
    }

    private static int countPrimes(int n) {
        boolean[] prime = new boolean[n];
        
        prime[0] = prime[1] = true;
        for (int i = 2; i*i <= n+1; i++){
            if(!prime[i]){
                for (int j = 2*i; j <= n; j+=i){
                    prime[j] = true;
                }
            }
        }
        int c = 0;
        for (int i=0 ; i < prime.length; i++){
            if(!prime[i]){
                c++;
            }
        }

        return c;
    }
}
