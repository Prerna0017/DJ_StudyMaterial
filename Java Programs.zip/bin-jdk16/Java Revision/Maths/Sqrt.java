package Maths;

public class Sqrt{
    public static void main(String[] args) {
        System.out.println(getSqrt(40, 3));
    }

    public static double getSqrt(int num, int precision){
        
        int  start = 0;
        int end = num;
        double root = 0.00;
        while ( start <= end){
            int mid = start + (end - start) / 2;
            if(mid*mid == num){
                return mid;
            }
            if (num < mid*mid){
                end = mid - 1;
            }
            else{
                start = mid + 1;
                root = mid;
            }
        }
        double increment = 0.1;
        for (int i = 0; i < precision; i++){
            while (root*root <= num){
                root += increment;
            }
            root -= increment;
            increment /= 10;

        }
        
        return root;
    }
}