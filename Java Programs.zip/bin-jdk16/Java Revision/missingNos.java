// import java.util.ArrayList;
import java.util.ArrayList;
// import java.util.List;
import java.util.Arrays;

class missingNos {

    public static void main(String[] args) {
        int[] arr = {1,2};
        // missingNumber(arr);
        System.out.println(missingNumber(arr));
        System.out.println(Arrays.toString(arr));
    }

    public static ArrayList<Integer> missingNumber(int[] arr) {
        
        ArrayList<Integer> missingNos = new ArrayList<>();
        
        int i = 0;
        while(i<arr.length){
            if (arr[i] != i+1){
                if (arr[i] == arr[arr[i]-1]){
                    i++;
                }
                else{
                    swap (arr, i, arr[i]-1);
                }
            }
            else{
                i++;
            }
        }
        boolean duplicate = false;
        for(int index = 0; index<=arr.length-1; index++){
            if (arr[index] != index+1){
                missingNos.add(index+1);
                duplicate = true;
            }

            
        }
        if (missingNos.isEmpty()){
            if (duplicate){
                missingNos.add(arr.length);
            }
        }
        return missingNos;

    }
    public static void swap(int[] arr, int index1, int index2){
        int temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

}