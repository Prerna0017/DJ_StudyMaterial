import java.util.ArrayList;
import java.util.List;

// Given a list of unique words, return all the pairs of the distinct 
// indices (i, j) in the given list, so that the concatenation of the
//  two words words[i] + words[j] is a palindrome.

// Example 1:

// Input: words = ["abcd","dcba","lls","s","sssll"]
// Output: [[0,1],[1,0],[3,2],[2,4]]
// Explanation: The palindromes are ["dcbaabcd","abcddcba","slls","llssssll"]

public class PalindromePairs {
    public static void main(String[] args) {
        String[] words = {"abcd","dcba","lls","s","sssll"};
        System.out.println(palindromePairs(words));
    }

    public static List<List<Integer>> palindromePairs2(String[] words) {
        List<List<Integer>> ans=new ArrayList<List<Integer>>();
        for (int i = 0; i< words.length; i++){
            for (int j = 0; j<words.length; j++){
                if(i==j) continue;
                String word1 = words[i] + words[j];
                String rev1 = new StringBuffer(word1).reverse().toString();
                if(word1.equals(rev1)){
                    ArrayList<Integer> pairs=new ArrayList<Integer>();
                    pairs.add(i);
                    pairs.add(j);
                    if(!ans.contains(pairs)){
                        ans.add(pairs);
                    }

                };

                
            }
        }
        return ans;
    }

    public static List<List<Integer>> palindromePairs(String[] words) {
        List<List<Integer>> ans=new ArrayList<List<Integer>>();
        for (int i = 0; i< words.length; i++){
            for (int j = 1; j<words.length; j++){
                String word1 = words[i] + words[j];
                String word2 = words[j] + words[i];
                String rev1 = new StringBuffer(word1).reverse().toString();
                if(word1.equals(rev1)){
                    ArrayList<Integer> pairs=new ArrayList<Integer>();
                    pairs.add(i);
                    pairs.add(j);
                    if(!ans.contains(pairs)){
                        ans.add(pairs);
                    }

                };

                String rev2 = new StringBuffer(word2).reverse().toString();
                if(word2.equals(rev2)){
                    ArrayList<Integer> pairs=new ArrayList<Integer>();
                    pairs.add(i);
                    pairs.add(j);
                    if(!ans.contains(pairs)){
                        ans.add(pairs);
                    }
                };
                
            }
        }
        return ans;
    }
}
