import java.util.Scanner;
class p2ii
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Any String: ");
		String str = sc.nextLine();	//string input

		System.out.println("Enter Any Substring to be searched: ");
		String substr = sc.nextLine();	//string input

		int lastIndex = str.lastIndexOf(substr);
		if(lastIndex == - 1)
		{
         			System.out.println("Hello not found");
      		}
		else
		{
         			System.out.println("Last occurrence of "+substr+" is at index "+ lastIndex);
     	 	}
   	}
}