/* Program to accept a number from the user and throw an exception if tthe number is not an even number   */

import java.io.*;
class checkeven extends Exception
{
	checkeven(String msg)
	{
		super(msg);
	}
}

class excep2
{
	public static void main(String args[]) throws IOException
	{
		DataInputStream d = new DataInputStream(System.in);
		try
		{
			System.out.println("Enter any number: ");
			int n = Integer.parseInt(d.readLine());
			if(n%2==0)
			{
				System.out.println("Even Number");
			}
			else
			{
				throw new checkeven("you have entered odd number");
			}
		}
		catch(checkeven e)
		{
			System.out.println(e);
		}
		catch(IOException e)
		{
			System.out.println(e);
		}

		finally
		{
			System.out.println("Execution continues......");
		}
	}
}