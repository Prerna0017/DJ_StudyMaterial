import java.util.Scanner;
class m2d
{  
	public static void main(String args[])
	{  
		Scanner input = new Scanner(System.in);

		System.out.println("Choose which basic operation you need to perform on 2 matrices");
		System.out.println("1. Addition");
		System.out.println("2. Subtraction");
		System.out.println("3. Multiplication");
		System.out.println("4. Divivsion");
		int op = input.nextInt();


		//creating two matrices    
		int a [][] = new int [2][2];	//2 rows and 2 columns  
		int b[][] = new int [2][2];	//2 rows and 2 columns  

		System.out.println("Enter the values for first 2*2 matrix");
		for(int i=0;i<2;i++)
		{    
			for(int j=0;j<2;j++)
			{    
				a[i][j] = input.nextInt();
			}    
			System.out.println();//new line    
		}    

		System.out.println("Enter the values for second 2*2 matrix");
		for(int i=0;i<2;i++)
		{    
			for(int j=0;j<2;j++)
			{    
				b[i][j] = input.nextInt();
			}    
			System.out.println();//new line    
		}    

    
		//creating another matrix to store the sum of two matrices    
		int c[][]=new int[2][2];  	//2 rows and 2 columns  
    
		if(op == 1)
		{ 
			System.out.println("Result of Adding two 2*2 matrices"); 
			for(int i=0;i<2;i++)
			{    
				for(int j=0;j<2;j++)
				{    
					c[i][j]=a[i][j]+b[i][j];    
					System.out.print(c[i][j]+" ");    
				}    
				System.out.println();//new line    
			}    
		}
		else if(op == 2)
		{ 
			System.out.println("Result of Subtracting two 2*2 matrices"); 
			for(int i=0;i<2;i++)
			{    
				for(int j=0;j<2;j++)
				{    
					c[i][j]=a[i][j]-b[i][j];    
					System.out.print(c[i][j]+" ");    
				}    
				System.out.println();//new line    
			}    
		}
		else if(op == 3)
		{ 
			System.out.println("Result of Multiplying two 2*2 matrices"); 
			for(int i=0;i<2;i++)
			{    
				for(int j=0;j<2;j++)
				{    
					c[i][j]=a[i][j]*b[i][j];    
					System.out.print(c[i][j]+" ");    
				}    
				System.out.println();//new line    
			}    
		}
		else
		{ 
			System.out.println("Result of Divivding two 2*2 matrices"); 
			for(int i=0;i<2;i++)
			{    
				for(int j=0;j<2;j++)
				{    
					c[i][j]=a[i][j]/b[i][j];    
					System.out.print(c[i][j]+" ");    
				}    
				System.out.println();//new line    
			}    
		}
	}	
}  