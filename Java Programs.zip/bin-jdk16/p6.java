import java.util.Scanner;
class p6
{
	public static void main (String[] args) 
 	{
		Scanner sc = new Scanner(System.in);

		String Password = new String("Abc123");

		System.out.println("Enter the password: ");
		String userPassword = sc.nextLine();	//string password input
		
		System.out.println("");
		if(Password.equals(userPassword))
		{
			System.out.println("Good, password is CORRECT");
		}
		else
		{
			System.out.println("Wrong Password");
		}
 
		System.out.println("");
        		// conversion from String object to StringBuffer
       		StringBuffer sbr = new StringBuffer(Password);
        		// To reverse the string
        		sbr.reverse();
        		System.out.println(sbr);

		System.out.println("");
		StringBuffer s1 = new StringBuffer(Password);
		StringBuffer s2 = new StringBuffer(" welcome");
		System.out.println(s1.append(s2));
		
  	}
}