import java.io.*;
class sbuf
{
	public static void main(String args[]) throws IOException
	{
		StringBuffer s1 = new StringBuffer("computer");
		StringBuffer s2 = new StringBuffer(" system");
		StringBuffer s3 = new StringBuffer(" computer");
		StringBuffer s4 = new StringBuffer(" system");
		StringBuffer s5 = new StringBuffer("Laptop");
		StringBuffer s6 = new StringBuffer("Engineering");
		StringBuffer s7 = new StringBuffer("Engineer");
		StringBuffer s8 = new StringBuffer("Physics");
		StringBuffer s9 = new StringBuffer("Mathematics");
		StringBuffer s10 = new StringBuffer("HookForCook");
		System.out.println("s1 = "+s1);
		s1.setCharAt(6,'a');
		System.out.println("s1 = "+s1);
		System.out.println(s1.append(s2));
		System.out.println("s1 = "+s1);
		System.out.println(s3.insert(3,s4));
		System.out.println("s3 = "+s3);
		s5.setLength(3);
		System.out.println("s5 = "+s5);
		s5.setLength(16);
		System.out.println("s6 = "+s6);
		System.out.println("s6 length = "+s6.length());
		System.out.println("s7 reversed = "+s7.reverse());
		System.out.println("delete characters = "+s8.delete(2,4));
		System.out.println("delete characters at specified position= "+s9.deleteCharAt(4));
		System.out.println("s10 replacing a set of character = "+s10.replace(4,7,"and"));
	}

}