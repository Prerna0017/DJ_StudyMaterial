import java.io.*;
class prime
{
	public static void main(String prerna[]) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int num,m;
		int i,flag=0;
		System.out.println("Enter value to check if it a prime number: ");
		num=Integer.parseInt(br.readLine());
		m=num/2;
		
		if(num==0||num==1)
		{  
   			System.out.println(num+" is not prime number");      
		}		
		else
		{  
   			for(i=2;i<=m;i++)
			{      
    				if(num%i==0)
				{      
     					System.out.println(num+" is not prime number");      
     					flag=1;      
     					break;      
    				}      
  			 }      
   			if(flag==0)  { System.out.println(num+" is prime number"); }  
  		}//end of else 
	}
}
		